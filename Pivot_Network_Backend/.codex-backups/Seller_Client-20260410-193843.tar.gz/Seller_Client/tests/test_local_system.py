from __future__ import annotations

import json
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from seller_client_app.config import Settings
from seller_client_app.local_system import run_standard_join_workflow


def _session_payload(*, manager_addr: str | None) -> dict[str, object]:
    return {
        "onboarding_session": {
            "session_id": "join-session-0001",
            "expected_wireguard_ip": "10.66.66.10",
            "swarm_join_material": {
                "manager_addr": manager_addr,
                "manager_port": 2377,
                "join_token": "join-token-1",
            },
        }
    }


class LocalSystemTests(unittest.TestCase):
    def test_run_standard_join_workflow_prefers_session_manager_addr(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            session_file = Path(tmpdir) / "session.json"
            session_file.write_text(json.dumps(_session_payload(manager_addr="10.66.66.1")), encoding="utf-8")
            settings = Settings(
                windows_workspace_root=tmpdir,
                manager_wireguard_address="192.0.2.44",
                manager_public_address="81.70.52.75",
            )

            with (
                patch("seller_client_app.local_system.platform.system", return_value="Windows"),
                patch(
                    "seller_client_app.local_system._run_process",
                    return_value={
                        "ok": True,
                        "command": [],
                        "exit_code": 0,
                        "stdout": '{"status":"ok"}',
                        "stderr": "",
                        "combined": '{"status":"ok"}',
                    },
                ) as run_process,
            ):
                result = run_standard_join_workflow(settings, session_file=str(session_file))

        self.assertTrue(result["ok"])
        command = run_process.call_args.args[0]
        manager_addr_index = command.index("-ManagerWireGuardAddress") + 1
        self.assertEqual(command[manager_addr_index], "10.66.66.1")

    def test_run_standard_join_workflow_requires_session_manager_addr(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            session_file = Path(tmpdir) / "session.json"
            session_file.write_text(json.dumps(_session_payload(manager_addr=None)), encoding="utf-8")
            settings = Settings(windows_workspace_root=tmpdir)

            with patch("seller_client_app.local_system.platform.system", return_value="Windows"):
                result = run_standard_join_workflow(settings, session_file=str(session_file))

        self.assertFalse(result["ok"])
        self.assertEqual(result["error"], "session_manager_addr_missing")


if __name__ == "__main__":
    unittest.main()
