# Server Handoff: Backend / Adapter / Swarm Reset For Windows Seller Reconnect

更新时间：`2026-04-09 23:22 CST`

## 1. 本次服务器侧已经发生的变更

### 1.1 Swarm manager 已经完成一次 fresh reset

这次不是只改文档，也不是只改 adapter 返回值，而是服务器上的 Docker Swarm manager 已经真实重建为一个 **新 cluster**。

当前服务器上的 manager 真相是：

- `ClusterID = mjs49dd6pfcngdrcruovc20lb`
- `NodeID = odtdolps6qyfpuvtfmdjnlctd`
- `NodeAddr = 10.66.66.1`
- `ManagerStatus.Addr = 10.66.66.1:2377`
- `docker swarm join-token worker` 返回目标：
  - `10.66.66.1:2377`

这意味着：

- 旧 cluster 的 node id / cluster id / join token 全部失效
- 旧 worker 记录已经不再属于当前 swarm 真相层
- Windows 侧必须按新 cluster 重新接入

### 1.2 Swarm 控制面已经从公网切到 WireGuard

之前错误的控制面入口是：

- `81.70.52.75:2377`

现在正确的控制面入口是：

- `10.66.66.1:2377`

当前服务器实测：

- `dockerd` 监听 `10.66.66.1:2377`
- manager gossip 也落在 `10.66.66.1`
- `docker node inspect self` 的 `Status.Addr` 是 `10.66.66.1`

所以从 Windows seller 角度，现在应该把：

- `81.70.52.75`

理解为：

- 服务器公网入口
- SSH / 域名 / 外网访问入口

而不再是：

- swarm join 目标地址

### 1.3 Adapter 的 join-material 语义已经变化

服务器 adapter 现在仍在：

- `/root/Pivot_network/Docker_Swarm/Docker_Swarm_Adapter`

但它现在返回的 `join-material` 已经与新的 manager 真相保持一致。

当前实测返回：

- `manager_addr = 10.66.66.1`
- `manager_port = 2377`
- `swarm_join_command = docker swarm join --token ... 10.66.66.1:2377`

这意味着 Windows seller client 以后不应该再把：

- `81.70.52.75:2377`

当成 join target。

应该以 backend 下发的新 session / 新 `swarm_join_material` 为准。

### 1.4 Backend 还在，但它没有切到 WG-only 暴露

服务器 backend 目录仍然是：

- `/root/Pivot_network/Plantform_Backend`

当前 backend 进程仍然是：

- `uvicorn backend_app.main:app --host 127.0.0.1 --port 8000`

也就是说 backend 本体仍然是：

- 本机回环监听 `127.0.0.1:8000`

对外正式入口仍然是：

- `https://pivotcompute.store`

所以对于 Windows seller client 来说：

- backend 公网入口没有变
- 变的是 backend 背后拿到的 swarm truth / join-material

### 1.5 Backend 到 Adapter 的内部调用关系没有变

当前 backend 仍通过本机地址访问 adapter：

- `BACKEND_ADAPTER_BASE_URL=http://127.0.0.1:8010`

这条内部链路没改成让 seller client 直连 adapter。

所以 seller client 仍然应该遵守原边界：

- seller client 只调 backend
- backend 再调 adapter

不要把 seller client 改成直接请求 adapter。

## 2. 这次变更对 Windows 卖家客户端的实际影响

### 2.1 旧 onboarding session 应视为过期

凡是在这次 swarm fresh reset 之前创建的 session，都不应该再继续拿来做正式接入。

原因不是 token 文本一定失效，而是这些 session 绑定的上下文已经过期，包括：

- 旧 cluster 语义
- 旧 node id
- 旧 manager node id
- 旧 manager acceptance 证据
- 旧 correction / re-verify 结论

建议直接把 reset 之前的 session 当成历史证据，不当成继续接入的工作基线。

### 2.2 旧 node_ref / 旧 manager node id 已失效

这次 reset 之后，之前文档里出现过的这些对象都不再属于当前 cluster：

- manager `t1p4v4byyo64dyefhd804wlzx`
- worker `1mwnvgqrg72jocqihbkxjrvdl`
- worker `9upsv4qd63ayhlzrlbqyos34k`

当前新 manager 是：

- `odtdolps6qyfpuvtfmdjnlctd`

因此 Windows 侧任何还写死旧 node id 的诊断逻辑，都应该视为旧证据，不能再拿来判断当前 swarm 真相。

### 2.3 旧“公网 join target”逻辑必须丢弃

Windows 侧如果还有任何逻辑在下面几种地方硬编码：

- `81.70.52.75:2377`
- “manager_addr 缺失时退回公网 join”
- “先尝试 public join，再 correction 到 WG”

这些逻辑现在都应该降级或去掉。

当前正确策略应当是：

1. 先从 backend 拉 fresh onboarding session
2. 读取 fresh `swarm_join_material`
3. 直接以 `manager_addr:manager_port` 为 join target
4. 当前预期应为 `10.66.66.1:2377`

## 3. Windows 卖家客户端现在应如何理解几个关键地址

### 3.1 这些值现在分别代表什么

- `backend_base_url`
  - 仍应是 `https://pivotcompute.store`
- `manager_public_address`
  - 仍应是 `81.70.52.75`
  - 用于 SSH / 公网入口 / 域名解析语境
- `manager_wireguard_address`
  - 仍应是 `10.66.66.1`
  - 用于 WG control-plane reachability / swarm join target
- `swarm_join_material.manager_addr`
  - 现在应当是 `10.66.66.1`
  - 这是 seller 这轮 join 的权威目标

### 3.2 当前 seller client 里建议保持不变的值

如果你在 Windows 那边调整 `seller_client`，下面这些默认值目前仍然合理：

- `SELLER_CLIENT_BACKEND_BASE_URL=https://pivotcompute.store`
- `SELLER_CLIENT_MANAGER_WIREGUARD_ADDRESS=10.66.66.1`
- `SELLER_CLIENT_MANAGER_PUBLIC_ADDRESS=81.70.52.75`
- `SELLER_CLIENT_DEFAULT_EXPECTED_WIREGUARD_IP=10.66.66.10`

也就是说：

- 公网 backend 地址没有变
- manager 的 WireGuard 地址没有变
- 变的是 swarm 真相层终于与这个 WG 地址一致了

## 4. Windows 侧重新接入时应该做的调整

### 4.1 以 fresh session 为唯一接入基线

重新接入时，应该：

1. 清理本地旧 join 状态
2. 不复用 reset 前的 onboarding session
3. 创建 fresh onboarding session
4. 读取 fresh `swarm_join_material`
5. 确认 `manager_addr = 10.66.66.1`
6. 再执行 join

如果 fresh session 拿到的 `manager_addr` 仍不是 `10.66.66.1`，那说明客户端拿到的不是当前真实 session，应该先停下来排查，而不是继续 join。

### 4.2 join target 应以 backend-issued material 为准

Windows 侧 join 逻辑建议锁定成：

- join target 来自 `session.onboarding_session.swarm_join_material.manager_addr:manager_port`
- 不自己拼公网 manager 地址
- 不把 `manager_public_address` 用作 swarm join target

### 4.3 本地 join 参数仍应坚持 WireGuard 地址

重新接入时，Windows 侧仍建议坚持：

- `--advertise-addr 10.66.66.10`
- `--data-path-addr 10.66.66.10`
- `--listen-addr 10.66.66.10:2377` 或当前脚本约定值

这里没有因为 server 变更而改成公网参数。

server 这次变更的目的恰恰是让：

- worker 的 WireGuard 自报
- manager 的真相层
- backend 的 join-material

三者终于朝同一个地址收敛。

### 4.4 不要把 seller client 改成直连 adapter

这次虽然 adapter 变了，但 seller client 侧仍不应跨过 backend 直接打 adapter。

当前边界仍然是：

- seller client -> backend
- backend -> adapter

客户端如果直接依赖 adapter，会引入新的耦合面，而且与现有 Phase 1/2 contract 不一致。

## 5. 推荐的 Windows 复接入顺序

建议按这个顺序执行：

1. 更新 Windows 本地 `seller_client` 到当前主线代码。
2. 清掉本地旧 join 状态，不延用旧 session。
3. 检查本地 WG：
   - `10.66.66.1` 可达
   - `2377/7946` 可达
   - 到 `10.66.66.1` 的路由走 `wg-seller`
4. 创建 fresh onboarding session。
5. 检查 session 里的 `swarm_join_material`：
   - `manager_addr` 必须是 `10.66.66.1`
   - `manager_port` 必须是 `2377`
6. 再执行官方 join / correction cycle。
7. join 后第一时间检查：
   - 本地 `docker info .Swarm.NodeAddr`
   - backend session 中的 fresh acceptance / correction
   - manager raw truth 是否最终看到 `10.66.66.10`

## 6. 当前可用于 Windows 侧 sanity-check 的服务器事实

截至 `2026-04-09 23:22 CST`，服务器当前应满足：

- backend health:
  - `http://127.0.0.1:8000/api/v1/health`
  - 返回 `{"status":"ok","service":"Plantform Backend"}`
- adapter health:
  - `http://127.0.0.1:8010/health`
  - 返回 `{"status":"ok","adapter":"swarm-adapter",...}`
- swarm overview:
  - manager 只有 1 个节点
  - manager 地址是 `10.66.66.1`
- `docker swarm join-token worker`
  - 输出目标是 `10.66.66.1:2377`

如果 Windows 侧拿到的结果与这些事实相矛盾，应优先怀疑：

- 还在用旧 session
- 还在用旧 join material
- 本地脚本仍把 join target 改回公网

## 7. 当前服务器上仍存在但不是本次主根因的残留

服务器上仍保留一批旧 `wg-home / 10.7.x.x / 51820` 残留：

- `/etc/wireguard/archive/wg-home.conf.disabled`
- `/etc/wireguard/archive/wg-home.privatekey.disabled`
- `/root/home-server.conf`
- `/root/wg-home-deploy`
- `wg-iptables.service`

其中 `wg-iptables.service` 现在还在生效旧规则：

- `10.7.0.0/24`
- `UDP 51820`

这批残留目前不是这次 seller 重新接入时必须先解决的 blocker，但如果后面还有奇怪的网络偏移，应该把它列入下一轮服务器清理项。

## 8. 服务器当前权威目录

服务器当前应以这些目录为准：

- seller client:
  - `/root/Pivot_network/Seller_Client`
- backend:
  - `/root/Pivot_network/Plantform_Backend`
- docker swarm / adapter:
  - `/root/Pivot_network/Docker_Swarm`

## 9. 给 Windows 侧的直接结论

给 Windows 卖家客户端这边最重要的结论只有四条：

1. backend 公网入口没变，仍是 `https://pivotcompute.store`。
2. swarm manager 已经重建成新 cluster，旧 session / 旧 node id / 旧 join 证据应视为过期。
3. 现在新的权威 join target 是 `10.66.66.1:2377`，不是 `81.70.52.75:2377`。
4. seller client 不需要改成直连 adapter，但必须改成严格信任 fresh backend-issued `swarm_join_material`。
