This directory holds archived Windows troubleshooting scripts that are no longer part of the public seller-client entry surface.

Current public entrypoints:

- `bootstrap/windows/install_and_check_seller_client.ps1`
- `bootstrap/windows/start_seller_client.ps1`

Current supported internal runners stay under `bootstrap/windows/`.
