from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Any

from seller_client_app.config import Settings
from seller_client_app.state import SellerClientState, SessionRuntimePaths


class CodexSessionError(Exception):
    pass


def prepare_codex_session(
    *,
    settings: Settings,
    state: SellerClientState,
    session_id: str,
) -> SessionRuntimePaths:
    paths = state.session_paths(session_id)
    paths.codex_dotdir.mkdir(parents=True, exist_ok=True)
    paths.logs_dir.mkdir(parents=True, exist_ok=True)
    paths.workspace_dir.mkdir(parents=True, exist_ok=True)

    config_template = settings.codex_config_template_path
    auth_source = settings.codex_auth_source_path
    if not config_template.exists():
        raise CodexSessionError(f"Missing Codex config template: {config_template}")
    if not auth_source.exists():
        raise CodexSessionError(f"Missing Codex auth source: {auth_source}")

    (paths.codex_dotdir / "config.toml").write_text(config_template.read_text(encoding="utf-8"), encoding="utf-8")
    (paths.codex_dotdir / "auth.json").write_text(auth_source.read_text(encoding="utf-8"), encoding="utf-8")

    session_file = state.write_session_runtime_file()
    if session_file is None:
        raise CodexSessionError("Onboarding session is not initialized.")
    try:
        _register_mcp_server(settings, paths)
    except (OSError, subprocess.SubprocessError) as exc:
        raise CodexSessionError(f"failed to register MCP server: {exc}") from exc
    return paths


def run_codex_assistant(
    *,
    settings: Settings,
    state: SellerClientState,
    session_id: str,
    user_message: str,
) -> dict[str, Any]:
    session_payload = state.current_onboarding_session()
    if session_payload is None:
        raise CodexSessionError("Onboarding session is not initialized.")

    paths = prepare_codex_session(settings=settings, state=state, session_id=session_id)
    output_file = paths.logs_dir / "assistant-last-message.txt"
    prompt = _build_assistant_prompt(state.runtime_snapshot(), user_message)
    env = _codex_env(paths)
    command = _codex_command(settings) + [
        "exec",
        "--skip-git-repo-check",
        "-s",
        settings.codex_exec_sandbox,
        "--cd",
        str(paths.workspace_dir),
        "--color",
        "never",
        "-o",
        str(output_file),
        prompt,
    ]
    process = subprocess.Popen(
        command,
        env=env,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
    )
    try:
        stdout, stderr = process.communicate(timeout=settings.codex_exec_timeout_seconds)
    except subprocess.TimeoutExpired as exc:
        process.kill()
        raise CodexSessionError("Codex assistant run timed out.") from exc

    if process.returncode != 0:
        raise CodexSessionError(stderr.strip() or stdout.strip() or "Codex assistant run failed.")

    assistant_message = output_file.read_text(encoding="utf-8").strip() if output_file.exists() else ""
    result = {
        "assistant_message": assistant_message,
        "stdout": stdout.strip(),
        "stderr": stderr.strip(),
        "log_file": str(output_file),
        "session_root": str(paths.session_root),
    }
    state.record_assistant_run(result)
    return result


def cleanup_codex_session(
    *,
    settings: Settings,
    state: SellerClientState,
    session_id: str,
) -> None:
    paths = state.session_paths(session_id)
    remove_command = _codex_command(settings) + [
        "mcp",
        "remove",
        _mcp_server_name(settings, session_id),
    ]
    try:
        subprocess.run(
            remove_command,
            env=_codex_env(paths),
            check=False,
            capture_output=True,
            text=True,
            timeout=15,
        )
    except Exception:
        pass
    state.cleanup_session(session_id)


def _register_mcp_server(settings: Settings, paths: SessionRuntimePaths) -> None:
    env = _codex_env(paths)
    server_name = _mcp_server_name(settings, paths.session_id)
    subprocess.run(
        _codex_command(settings) + ["mcp", "remove", server_name],
        env=env,
        check=False,
        capture_output=True,
        text=True,
        timeout=15,
    )
    command = _codex_command(settings) + [
        "mcp",
        "add",
        server_name,
        "--env",
        f"SELLER_CLIENT_SESSION_FILE={paths.session_file}",
        "--env",
        f"PYTHONPATH={Path(__file__).resolve().parent.parent}",
        "--",
        sys.executable,
        "-m",
        "seller_client_app.mcp_server",
        "--session-file",
        str(paths.session_file),
    ]
    completed = subprocess.run(command, env=env, check=False, capture_output=True, text=True, timeout=30)
    if completed.returncode != 0 and "already exists" not in (completed.stderr or completed.stdout):
        raise CodexSessionError(completed.stderr.strip() or completed.stdout.strip() or "failed to register MCP server")


def _mcp_server_name(settings: Settings, session_id: str) -> str:
    return f"{settings.codex_mcp_server_name_prefix}-{session_id[:8]}"


def _codex_env(paths: SessionRuntimePaths) -> dict[str, str]:
    env = os.environ.copy()
    env["HOME"] = str(paths.codex_home)
    env["SELLER_CLIENT_SESSION_FILE"] = str(paths.session_file)
    env["PYTHONPATH"] = str(Path(__file__).resolve().parent.parent)
    return env


def _codex_command(settings: Settings) -> list[str]:
    candidate = shutil.which(settings.codex_command)
    if candidate is None:
        raise CodexSessionError(f"Unable to locate Codex CLI command: {settings.codex_command}")
    return [candidate]


def _build_assistant_prompt(snapshot: dict[str, Any], user_message: str) -> str:
    return (
        "You are the seller onboarding assistant for Pivot Network.\n"
        "Use only the configured MCP tools for this session.\n"
        "Do not assume shell access and do not ask the user to edit files manually.\n"
        "Work from the existing backend onboarding contract and the generated phase-1 drafts.\n"
        "If a required runtime fact is missing, state the exact missing field instead of guessing.\n"
        "Current local state:\n"
        f"{json.dumps(snapshot, ensure_ascii=False, indent=2)}\n\n"
        "User request:\n"
        f"{user_message}\n"
    )
