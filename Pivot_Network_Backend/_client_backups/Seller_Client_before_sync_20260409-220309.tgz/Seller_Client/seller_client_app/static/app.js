let windowSessionId = null;
let windowHeartbeatTimer = null;

const onboardingSessionStorageKey = "pivot-seller-current-session-id";

function getStoredOnboardingSessionId() {
  return window.localStorage.getItem(onboardingSessionStorageKey);
}

function setStoredOnboardingSessionId(sessionId) {
  if (!sessionId) {
    return;
  }
  window.localStorage.setItem(onboardingSessionStorageKey, sessionId);
  renderStoredSessionStatus(sessionId);
}

function clearStoredOnboardingSessionId() {
  window.localStorage.removeItem(onboardingSessionStorageKey);
  renderStoredSessionStatus(null);
}

function renderWindowSessionStatus(payload) {
  const target = document.getElementById("window-session-status");
  if (!target) {
    return;
  }
  if (!payload || !payload.session_id) {
    target.textContent = "窗口 session 未初始化";
    return;
  }
  target.textContent = `窗口 session: ${payload.session_id} / TTL ${payload.ttl_seconds}s`;
}

function renderStoredSessionStatus(sessionId) {
  const target = document.getElementById("stored-session-status");
  if (!target) {
    return;
  }
  if (!sessionId) {
    target.textContent = "本地未保存 onboarding session_id";
    return;
  }
  target.textContent = `本地保存的 onboarding session_id: ${sessionId}`;
}

async function api(path, options = {}) {
  const headers = { ...(options.headers || {}) };
  if (!headers["Content-Type"] && options.body !== undefined) {
    headers["Content-Type"] = "application/json";
  }
  if (windowSessionId) {
    headers["X-Window-Session-Id"] = windowSessionId;
  }
  const response = await fetch(path, { ...options, headers });
  const payload = await response.json().catch(() => ({}));
  if (!response.ok) {
    const error = new Error(payload?.error?.message || payload?.detail || "Request failed");
    error.payload = payload;
    error.status = response.status;
    throw error;
  }
  return payload;
}

function writeOutput(id, payload) {
  const target = document.getElementById(id);
  if (!target) {
    return;
  }
  target.textContent = JSON.stringify(payload, null, 2);
}

function clearFeedback(id) {
  const box = document.getElementById(id);
  if (!box) {
    return;
  }
  box.className = "feedback hidden";
  box.innerHTML = "";
}

function renderFeedback(id, payload, kind = "error") {
  const box = document.getElementById(id);
  if (!box) {
    return;
  }
  const error = payload?.error || payload;
  const step = error.step ? `<p><strong>步骤</strong> ${error.step}</p>` : "";
  const code = error.code ? `<p><strong>代码</strong> ${error.code}</p>` : "";
  const hint = error.hint ? `<p><strong>建议</strong> ${error.hint}</p>` : "";
  box.className = `feedback ${kind}`;
  box.innerHTML = `<h3>${error.message || "请求失败"}</h3>${step}${code}${hint}`;
}

function handleError(outputId, feedbackId, error) {
  const payload = error.payload || { error: { message: String(error) } };
  renderFeedback(feedbackId, payload);
  writeOutput(outputId, payload);
}

function parseJsonEditor(id) {
  const raw = document.getElementById(id).value.trim();
  if (!raw) {
    return {};
  }
  return JSON.parse(raw);
}

function renderDraftEditors(drafts) {
  const payloads = drafts?.write_payloads || {};
  document.getElementById("host-probe-editor").value = JSON.stringify(payloads.linux_host_probe || {}, null, 2);
  document.getElementById("substrate-probe-editor").value = JSON.stringify(payloads.linux_substrate_probe || {}, null, 2);
  document.getElementById("runtime-probe-editor").value = JSON.stringify(payloads.container_runtime_probe || {}, null, 2);
  document.getElementById("join-complete-editor").value = JSON.stringify(payloads.join_complete || {}, null, 2);
  writeOutput("join-output", drafts);
}

async function ensureWindowSession() {
  if (windowSessionId) {
    return;
  }
  const payload = await api("/local-api/window-session/open", {
    method: "POST",
    body: JSON.stringify({}),
  });
  windowSessionId = payload.session_id;
  renderWindowSessionStatus(payload);
  if (windowHeartbeatTimer) {
    window.clearInterval(windowHeartbeatTimer);
  }
  windowHeartbeatTimer = window.setInterval(async () => {
    if (!windowSessionId) {
      return;
    }
    try {
      const heartbeat = await api("/local-api/window-session/heartbeat", {
        method: "POST",
        body: JSON.stringify({}),
      });
      renderWindowSessionStatus(heartbeat);
    } catch (error) {
      console.warn("window session heartbeat failed", error);
    }
  }, 15000);
}

async function pollJob(jobId, outputId, feedbackId) {
  while (true) {
    const payload = await api(`/local-api/jobs/${jobId}`, { method: "GET" });
    writeOutput(outputId, payload);
    if (payload.status === "succeeded" || payload.status === "failed") {
      if (payload.status === "failed") {
        renderFeedback(feedbackId, { error: payload.error || { message: "Job failed" } });
      } else {
        clearFeedback(feedbackId);
      }
      return payload;
    }
    await new Promise((resolve) => window.setTimeout(resolve, 1200));
  }
}

async function refreshSnapshot() {
  const snapshot = await api("/local-api/onboarding/current", { method: "GET" });
  writeOutput("status-output", snapshot);
  const sessionId = snapshot?.onboarding_session?.session_id || null;
  if (sessionId) {
    setStoredOnboardingSessionId(sessionId);
  }
  return snapshot;
}

async function attachStoredSession() {
  const sessionId = getStoredOnboardingSessionId();
  if (!sessionId) {
    throw new Error("No saved onboarding session_id in browser storage.");
  }
  const payload = await api("/local-api/onboarding/attach", {
    method: "POST",
    body: JSON.stringify({ session_id: sessionId }),
  });
  clearFeedback("session-feedback");
  setStoredOnboardingSessionId(payload.session.session_id);
  writeOutput("session-output", payload);
  renderDraftEditors(payload.phase1_drafts);
  await refreshSnapshot();
  return payload;
}

async function submitProbe(path, editorId) {
  const payload = parseJsonEditor(editorId);
  const result = await api(path, {
    method: "POST",
    body: JSON.stringify(payload),
  });
  const sessionId = result?.session_id || result?.last_join_complete?.join_session_id || getStoredOnboardingSessionId();
  if (sessionId) {
    setStoredOnboardingSessionId(sessionId);
  }
  writeOutput("join-output", result);
  writeOutput("status-output", result);
  return result;
}

window.addEventListener("beforeunload", () => {
  if (!windowSessionId) {
    return;
  }
  fetch("/local-api/window-session/close", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "X-Window-Session-Id": windowSessionId,
    },
    body: JSON.stringify({}),
    keepalive: true,
  }).catch(() => {});
});

window.addEventListener("load", async () => {
  renderStoredSessionStatus(getStoredOnboardingSessionId());
  try {
    await ensureWindowSession();
    await refreshSnapshot();
  } catch (error) {
    handleError("status-output", "session-feedback", error);
  }
});

document.getElementById("login-form").addEventListener("submit", async (event) => {
  event.preventDefault();
  await ensureWindowSession();
  const form = new FormData(event.target);
  try {
    const result = await api("/local-api/auth/login", {
      method: "POST",
      body: JSON.stringify({
        email: form.get("email"),
        password: form.get("password"),
      }),
    });
    clearFeedback("login-feedback");
    writeOutput("login-output", result);
    if (getStoredOnboardingSessionId()) {
      try {
        await attachStoredSession();
      } catch (attachError) {
        handleError("session-output", "session-feedback", attachError);
      }
    }
  } catch (error) {
    handleError("login-output", "login-feedback", error);
  }
});

document.getElementById("session-form").addEventListener("submit", async (event) => {
  event.preventDefault();
  await ensureWindowSession();
  const form = new FormData(event.target);
  try {
    const result = await api("/local-api/onboarding/start", {
      method: "POST",
      body: JSON.stringify({
        requested_accelerator: form.get("requested_accelerator"),
        requested_compute_node_id: form.get("requested_compute_node_id") || null,
        requested_offer_tier: form.get("requested_offer_tier") || null,
      }),
    });
    clearFeedback("session-feedback");
    setStoredOnboardingSessionId(result.session.session_id);
    writeOutput("session-output", result);
    renderDraftEditors(result.phase1_drafts);
    await refreshSnapshot();
  } catch (error) {
    handleError("session-output", "session-feedback", error);
  }
});

document.getElementById("attach-session").addEventListener("click", async () => {
  try {
    await ensureWindowSession();
    await attachStoredSession();
  } catch (error) {
    handleError("session-output", "session-feedback", error);
  }
});

document.getElementById("refresh-session").addEventListener("click", async () => {
  try {
    await ensureWindowSession();
    const result = await api("/local-api/onboarding/refresh", {
      method: "POST",
      body: JSON.stringify({}),
    });
    clearFeedback("session-feedback");
    writeOutput("session-output", result);
    writeOutput("status-output", result);
  } catch (error) {
    handleError("session-output", "session-feedback", error);
  }
});

document.getElementById("close-session").addEventListener("click", async () => {
  try {
    await ensureWindowSession();
    const result = await api("/local-api/onboarding/close", {
      method: "POST",
      body: JSON.stringify({}),
    });
    clearFeedback("session-feedback");
    clearStoredOnboardingSessionId();
    writeOutput("session-output", result);
    writeOutput("status-output", result.snapshot || result);
  } catch (error) {
    handleError("session-output", "session-feedback", error);
  }
});

document.getElementById("assistant-form").addEventListener("submit", async (event) => {
  event.preventDefault();
  await ensureWindowSession();
  const form = new FormData(event.target);
  try {
    const job = await api("/local-api/assistant/message", {
      method: "POST",
      body: JSON.stringify({ message: form.get("message") }),
    });
    clearFeedback("assistant-feedback");
    const result = await pollJob(job.job_id, "assistant-output", "assistant-feedback");
    if (result.result) {
      writeOutput("assistant-output", result.result);
    }
  } catch (error) {
    handleError("assistant-output", "assistant-feedback", error);
  }
});

document.getElementById("load-drafts").addEventListener("click", async () => {
  try {
    await ensureWindowSession();
    const drafts = await api("/local-api/onboarding/phase1-drafts", { method: "GET" });
    clearFeedback("join-feedback");
    renderDraftEditors(drafts);
    await refreshSnapshot();
  } catch (error) {
    handleError("join-output", "join-feedback", error);
  }
});

document.getElementById("refresh-status").addEventListener("click", async () => {
  try {
    await ensureWindowSession();
    clearFeedback("join-feedback");
    await refreshSnapshot();
  } catch (error) {
    handleError("status-output", "join-feedback", error);
  }
});

document.getElementById("submit-host-probe").addEventListener("click", async () => {
  try {
    await ensureWindowSession();
    clearFeedback("join-feedback");
    await submitProbe("/local-api/onboarding/probes/linux-host", "host-probe-editor");
  } catch (error) {
    handleError("join-output", "join-feedback", error);
  }
});

document.getElementById("submit-substrate-probe").addEventListener("click", async () => {
  try {
    await ensureWindowSession();
    clearFeedback("join-feedback");
    await submitProbe("/local-api/onboarding/probes/linux-substrate", "substrate-probe-editor");
  } catch (error) {
    handleError("join-output", "join-feedback", error);
  }
});

document.getElementById("submit-runtime-probe").addEventListener("click", async () => {
  try {
    await ensureWindowSession();
    clearFeedback("join-feedback");
    await submitProbe("/local-api/onboarding/probes/container-runtime", "runtime-probe-editor");
  } catch (error) {
    handleError("join-output", "join-feedback", error);
  }
});

document.getElementById("submit-join-complete").addEventListener("click", async () => {
  try {
    await ensureWindowSession();
    clearFeedback("join-feedback");
    await submitProbe("/local-api/onboarding/join-complete", "join-complete-editor");
  } catch (error) {
    handleError("join-output", "join-feedback", error);
  }
});
