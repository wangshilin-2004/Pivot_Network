from __future__ import annotations

from pathlib import Path
from typing import Any

from fastapi import FastAPI, Request
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, ConfigDict, Field

from seller_client_app.backend import BackendClient, BackendClientError
from seller_client_app.codex_session import CodexSessionError, cleanup_codex_session, prepare_codex_session, run_codex_assistant
from seller_client_app.config import get_settings
from seller_client_app.errors import LocalAppError
from seller_client_app.onboarding import build_phase1_drafts_from_session
from seller_client_app.state import SellerClientState

settings = get_settings()
state = SellerClientState(settings)
app = FastAPI(title="Pivot Seller Client", version="0.2.0")
static_dir = Path(__file__).resolve().parent / "static"
app.mount("/static", StaticFiles(directory=static_dir), name="static")


class StrictModel(BaseModel):
    model_config = ConfigDict(extra="forbid")


class LoginRequest(StrictModel):
    email: str = Field(min_length=3)
    password: str = Field(min_length=8)


class RegisterRequest(StrictModel):
    email: str = Field(min_length=3)
    display_name: str = Field(min_length=1)
    password: str = Field(min_length=8)
    role: str = "seller"


class OnboardingStartRequest(StrictModel):
    requested_accelerator: str = "gpu"
    requested_compute_node_id: str | None = None
    requested_offer_tier: str | None = None


class OnboardingAttachRequest(StrictModel):
    session_id: str = Field(min_length=1)


class AssistantMessageRequest(StrictModel):
    message: str = Field(min_length=1)


class LinuxHostProbeRequest(StrictModel):
    reported_phase: str | None = None
    host_name: str | None = None
    os_name: str | None = None
    distribution_name: str | None = None
    kernel_release: str | None = None
    virtualization_available: bool | None = None
    sudo_available: bool | None = None
    observed_ips: list[str] = Field(default_factory=list)
    notes: list[str] = Field(default_factory=list)
    raw_payload: dict[str, Any] = Field(default_factory=dict)


class LinuxSubstrateProbeRequest(StrictModel):
    reported_phase: str | None = None
    distribution_name: str | None = None
    kernel_release: str | None = None
    docker_available: bool | None = None
    docker_version: str | None = None
    wireguard_available: bool | None = None
    gpu_available: bool | None = None
    cpu_cores: int | None = None
    memory_gb: int | None = None
    disk_free_gb: int | None = None
    observed_ips: list[str] = Field(default_factory=list)
    observed_wireguard_ip: str | None = None
    observed_advertise_addr: str | None = None
    observed_data_path_addr: str | None = None
    notes: list[str] = Field(default_factory=list)
    raw_payload: dict[str, Any] = Field(default_factory=dict)


class ContainerRuntimeProbeRequest(StrictModel):
    reported_phase: str | None = None
    runtime_name: str | None = None
    runtime_version: str | None = None
    engine_available: bool | None = None
    image_store_accessible: bool | None = None
    network_ready: bool | None = None
    observed_images: list[str] = Field(default_factory=list)
    notes: list[str] = Field(default_factory=list)
    raw_payload: dict[str, Any] = Field(default_factory=dict)


class JoinCompleteRequest(StrictModel):
    reported_phase: str | None = None
    node_ref: str | None = None
    compute_node_id: str | None = None
    observed_wireguard_ip: str | None = None
    observed_advertise_addr: str | None = None
    observed_data_path_addr: str | None = None
    notes: list[str] = Field(default_factory=list)
    raw_payload: dict[str, Any] = Field(default_factory=dict)


class CorrectionEvidenceRequest(StrictModel):
    correction_kind: str = Field(min_length=1, max_length=64)
    outcome: str = Field(min_length=1, max_length=32)
    reported_phase: str | None = None
    join_mode: str | None = None
    target_host: str | None = None
    target_port: int | None = Field(default=None, ge=1, le=65535)
    observed_wireguard_ip: str | None = None
    observed_advertise_addr: str | None = None
    observed_data_path_addr: str | None = None
    manager_node_addr_hint: str | None = None
    script_path: str | None = None
    log_path: str | None = None
    rollback_path: str | None = None
    notes: list[str] = Field(default_factory=list)
    raw_payload: dict[str, Any] = Field(default_factory=dict)


class TcpValidationRequest(StrictModel):
    host: str = Field(min_length=1, max_length=255)
    port: int = Field(ge=1, le=65535)
    timeout_ms: int = Field(default=3000, ge=1, le=60000)
    validation_kind: str | None = None
    source: str | None = None
    target_label: str | None = None
    notes: list[str] = Field(default_factory=list)
    raw_payload: dict[str, Any] = Field(default_factory=dict)


@app.exception_handler(LocalAppError)
def handle_local_app_error(_: Request, exc: LocalAppError) -> JSONResponse:
    return JSONResponse(status_code=exc.status_code, content=exc.to_dict())


@app.exception_handler(Exception)
def handle_unexpected_error(_: Request, exc: Exception) -> JSONResponse:
    if isinstance(exc, LocalAppError):
        return JSONResponse(status_code=exc.status_code, content=exc.to_dict())
    return JSONResponse(
        status_code=500,
        content={
            "error": {
                "step": "local_api",
                "code": "local_internal_error",
                "message": "Seller client encountered an unexpected internal error.",
                "hint": "Check the local seller client logs and retry after fixing the reported issue.",
                "details": {"exception": str(exc)},
            }
        },
    )


@app.get("/", include_in_schema=False)
def root() -> FileResponse:
    return FileResponse(static_dir / "index.html")


@app.post("/local-api/window-session/open")
def window_session_open() -> dict[str, Any]:
    return state.open_window_session()


@app.post("/local-api/window-session/heartbeat")
def window_session_heartbeat(request: Request) -> dict[str, Any]:
    window_session = _require_window_session(request)
    return state.heartbeat_window_session(window_session["session_id"])


@app.post("/local-api/window-session/close")
def window_session_close(request: Request) -> dict[str, Any]:
    current = state.current_window_session()
    if current is None:
        return {"status": "already_closed"}

    window_session = _require_window_session(request)
    _close_active_onboarding(best_effort=True)
    closed = state.close_window_session(window_session["session_id"])
    return {"status": "closed", "window_session": closed}


@app.post("/local-api/auth/register")
def local_register(payload: RegisterRequest) -> dict[str, Any]:
    client = BackendClient(settings)
    try:
        response = client.register(payload.email, payload.display_name, payload.password, role=payload.role)
    except BackendClientError as exc:
        raise _backend_error(
            "auth.register",
            exc,
            message="Failed to register the seller account on the backend.",
            hint="Check backend connectivity and confirm the email is not already registered.",
        ) from exc
    state.set_auth(response["access_token"], response["user"], response.get("expires_at"))
    return {
        "user": response["user"],
        "expires_at": response["expires_at"],
    }


@app.post("/local-api/auth/login")
def local_login(payload: LoginRequest) -> dict[str, Any]:
    client = BackendClient(settings)
    try:
        response = client.login(payload.email, payload.password)
    except BackendClientError as exc:
        raise _backend_error(
            "auth.login",
            exc,
            message="Failed to log in to the platform backend.",
            hint="Confirm backend URL, seller account, password, and outbound HTTPS connectivity.",
        ) from exc
    state.set_auth(response["access_token"], response["user"], response.get("expires_at"))
    return {
        "user": response["user"],
        "expires_at": response["expires_at"],
    }


@app.post("/local-api/onboarding/start")
def onboarding_start(payload: OnboardingStartRequest, request: Request) -> dict[str, Any]:
    _require_window_session(request)
    client = _require_backend_client()
    try:
        session_payload = client.create_onboarding_session(
            requested_accelerator=payload.requested_accelerator,
            requested_compute_node_id=payload.requested_compute_node_id,
            requested_offer_tier=payload.requested_offer_tier,
        )
    except BackendClientError as exc:
        raise _backend_error(
            "onboarding.start",
            exc,
            message="Failed to create the seller onboarding session.",
            hint="Confirm backend connectivity and seller permissions, then retry.",
        ) from exc

    paths = state.set_onboarding(session_payload)
    try:
        prepare_codex_session(settings=settings, state=state, session_id=session_payload["session_id"])
    except CodexSessionError as exc:
        try:
            client.close_onboarding_session(session_payload["session_id"])
        except BackendClientError:
            pass
        state.cleanup_session(session_payload["session_id"])
        raise LocalAppError(
            step="onboarding.codex",
            code="codex_session_init_failed",
            message="Failed to initialize the session-scoped Codex environment.",
            hint="Confirm Codex CLI, the config template, and ~/.codex/auth.json exist on this machine.",
            details={"exception": str(exc)},
            status_code=500,
        ) from exc

    _start_onboarding_heartbeat()
    return {
        "session": session_payload,
        "phase1_drafts": build_phase1_drafts_from_session(session_payload),
        "paths": {
            "session_root": str(paths.session_root),
            "session_file": str(paths.session_file),
            "logs_dir": str(paths.logs_dir),
            "workspace_dir": str(paths.workspace_dir),
        },
    }


@app.post("/local-api/onboarding/attach")
def onboarding_attach(payload: OnboardingAttachRequest, request: Request) -> dict[str, Any]:
    _require_window_session(request)
    current = state.current_onboarding_session()
    if current is not None and current["session_id"] != payload.session_id:
        _close_active_onboarding(best_effort=True)

    client = _require_backend_client()
    try:
        session_payload = client.get_onboarding_session(payload.session_id)
    except BackendClientError as exc:
        raise _backend_error(
            "onboarding.attach",
            exc,
            message="Failed to attach the stored onboarding session.",
            hint="Check the saved session id and confirm the session still exists on the backend.",
        ) from exc

    paths = state.set_onboarding(session_payload)
    try:
        prepare_codex_session(settings=settings, state=state, session_id=session_payload["session_id"])
    except CodexSessionError as exc:
        state.cleanup_session(session_payload["session_id"])
        raise LocalAppError(
            step="onboarding.attach.codex",
            code="codex_session_init_failed",
            message="Failed to reattach the local Codex session for the stored onboarding session.",
            hint="Confirm Codex CLI, the config template, and ~/.codex/auth.json exist on this machine.",
            details={"exception": str(exc)},
            status_code=500,
        ) from exc

    _start_onboarding_heartbeat()
    return {
        "session": session_payload,
        "phase1_drafts": build_phase1_drafts_from_session(session_payload),
        "paths": {
            "session_root": str(paths.session_root),
            "session_file": str(paths.session_file),
            "logs_dir": str(paths.logs_dir),
            "workspace_dir": str(paths.workspace_dir),
        },
    }


@app.get("/local-api/onboarding/current")
def onboarding_current(request: Request) -> dict[str, Any]:
    _require_window_session(request)
    return state.runtime_snapshot()


@app.post("/local-api/onboarding/refresh")
def onboarding_refresh(request: Request) -> dict[str, Any]:
    _require_window_session(request)
    client = _require_backend_client()
    session_payload = _require_onboarding_session()
    try:
        updated = client.get_onboarding_session(session_payload["session_id"])
    except BackendClientError as exc:
        raise _backend_error(
            "onboarding.refresh",
            exc,
            message="Failed to refresh the onboarding session from the backend.",
            hint="Check backend connectivity and confirm the onboarding session is still active.",
        ) from exc
    state.update_onboarding_session(updated)
    return state.runtime_snapshot()


@app.get("/local-api/onboarding/phase1-drafts")
def onboarding_phase1_drafts(request: Request) -> dict[str, Any]:
    _require_window_session(request)
    return build_phase1_drafts_from_session(_require_onboarding_session())


@app.post("/local-api/onboarding/probes/linux-host")
def submit_linux_host_probe(payload: LinuxHostProbeRequest, request: Request) -> dict[str, Any]:
    _require_window_session(request)
    client = _require_backend_client()
    session_payload = _require_onboarding_session()
    try:
        updated = client.submit_linux_host_probe(session_payload["session_id"], _compact_model(payload))
    except BackendClientError as exc:
        raise _backend_error(
            "onboarding.linux_host_probe",
            exc,
            message="Failed to submit the Linux host probe.",
            hint="Check the payload shape against the current onboarding contract, then retry.",
        ) from exc
    state.update_onboarding_session(updated)
    return updated


@app.post("/local-api/onboarding/probes/linux-substrate")
def submit_linux_substrate_probe(payload: LinuxSubstrateProbeRequest, request: Request) -> dict[str, Any]:
    _require_window_session(request)
    client = _require_backend_client()
    session_payload = _require_onboarding_session()
    try:
        updated = client.submit_linux_substrate_probe(session_payload["session_id"], _compact_model(payload))
    except BackendClientError as exc:
        raise _backend_error(
            "onboarding.linux_substrate_probe",
            exc,
            message="Failed to submit the Linux substrate probe.",
            hint="Check the reported fields and retry after correcting the payload.",
        ) from exc
    state.update_onboarding_session(updated)
    return updated


@app.post("/local-api/onboarding/probes/container-runtime")
def submit_container_runtime_probe(payload: ContainerRuntimeProbeRequest, request: Request) -> dict[str, Any]:
    _require_window_session(request)
    client = _require_backend_client()
    session_payload = _require_onboarding_session()
    try:
        updated = client.submit_container_runtime_probe(session_payload["session_id"], _compact_model(payload))
    except BackendClientError as exc:
        raise _backend_error(
            "onboarding.container_runtime_probe",
            exc,
            message="Failed to submit the container runtime probe.",
            hint="Confirm the runtime probe values and retry.",
        ) from exc
    state.update_onboarding_session(updated)
    return updated


@app.post("/local-api/onboarding/join-complete")
def submit_join_complete(payload: JoinCompleteRequest, request: Request) -> dict[str, Any]:
    _require_window_session(request)
    client = _require_backend_client()
    session_payload = _require_onboarding_session()
    try:
        updated = client.submit_join_complete(session_payload["session_id"], _compact_model(payload))
    except BackendClientError as exc:
        raise _backend_error(
            "onboarding.join_complete",
            exc,
            message="Failed to submit join-complete to the backend.",
            hint="Provide compute_node_id or node_ref and ensure the payload stays flat.",
        ) from exc
    state.update_onboarding_session(updated)
    return updated


@app.post("/local-api/onboarding/correction")
def record_runtime_correction(payload: CorrectionEvidenceRequest, request: Request) -> dict[str, Any]:
    _require_window_session(request)
    _require_onboarding_session()
    try:
        return state.record_correction_evidence(_compact_model(payload))
    except ValueError as exc:
        raise LocalAppError(
            step="onboarding.correction",
            code="correction_payload_invalid",
            message="Failed to record local correction evidence.",
            hint="Provide the correction kind, outcome, and any local address facts before retrying.",
            details={"exception": str(exc)},
            status_code=400,
        ) from exc


@app.post("/local-api/onboarding/tcp-validation")
def run_minimum_tcp_validation(payload: TcpValidationRequest, request: Request) -> dict[str, Any]:
    _require_window_session(request)
    _require_onboarding_session()
    try:
        return state.record_tcp_validation(_compact_model(payload))
    except ValueError as exc:
        raise LocalAppError(
            step="onboarding.tcp_validation",
            code="tcp_validation_payload_invalid",
            message="Failed to run the local minimum TCP validation.",
            hint="Provide a reachable host, port, and timeout before retrying.",
            details={"exception": str(exc)},
            status_code=400,
        ) from exc


@app.post("/local-api/assistant/message")
def assistant_message(payload: AssistantMessageRequest, request: Request) -> dict[str, Any]:
    _require_window_session(request)
    session_payload = _require_onboarding_session()
    job = state.jobs.submit(
        "assistant_message",
        lambda: run_codex_assistant(
            settings=settings,
            state=state,
            session_id=session_payload["session_id"],
            user_message=payload.message,
        ),
    )
    return {"job_id": job.job_id, "status": job.status}


@app.get("/local-api/jobs/{job_id}")
def job_status(job_id: str, request: Request) -> dict[str, Any]:
    _require_window_session(request)
    record = state.jobs.get(job_id)
    if record is None:
        raise LocalAppError(
            step="jobs.status",
            code="job_not_found",
            message="Job was not found.",
            hint="Refresh the page and rerun the action if the local job record was lost.",
            status_code=404,
        )
    return record.to_dict()


@app.post("/local-api/onboarding/close")
def onboarding_close(request: Request) -> dict[str, Any]:
    _require_window_session(request)
    result = _close_active_onboarding(best_effort=False)
    return {"status": "closed", "session": result, "snapshot": state.runtime_snapshot()}


def _require_window_session(request: Request) -> dict[str, Any]:
    return state.require_window_session(request.headers.get("X-Window-Session-Id"))


def _require_backend_client() -> BackendClient:
    token = state.auth_token()
    if token is None:
        raise LocalAppError(
            step="auth",
            code="auth_required",
            message="Seller login is required before calling the local onboarding shell.",
            hint="Log in from the seller client first.",
            status_code=401,
        )
    return BackendClient(settings, token=token)


def _require_onboarding_session() -> dict[str, Any]:
    session_payload = state.current_onboarding_session()
    if session_payload is None:
        raise LocalAppError(
            step="onboarding",
            code="onboarding_session_missing",
            message="Onboarding session is not initialized.",
            hint="Start a seller onboarding session before using this action.",
            status_code=409,
        )
    return session_payload


def _close_active_onboarding(*, best_effort: bool) -> dict[str, Any] | None:
    session_payload = state.current_onboarding_session()
    if session_payload is None:
        return None
    cleanup_needed = best_effort
    try:
        if state.auth_token():
            client = _require_backend_client()
            session_payload = client.close_onboarding_session(session_payload["session_id"])
        cleanup_needed = True
    except BackendClientError as exc:
        if not best_effort:
            raise _backend_error(
                "onboarding.close",
                exc,
                message="Failed to close the onboarding session on the backend.",
                hint="Refresh the session and retry close after backend connectivity is restored.",
            ) from exc
    finally:
        if cleanup_needed:
            cleanup_codex_session(settings=settings, state=state, session_id=session_payload["session_id"])
    return session_payload


def _backend_error(step: str, exc: BackendClientError, *, message: str, hint: str) -> LocalAppError:
    return LocalAppError(
        step=step,
        code="backend_request_failed",
        message=message,
        hint=hint,
        details=exc.payload or {"detail": exc.detail},
        status_code=exc.status_code if 400 <= exc.status_code < 600 else 502,
    )


def _compact_model(payload: BaseModel) -> dict[str, Any]:
    return payload.model_dump(exclude_none=True)


def _start_onboarding_heartbeat() -> None:
    def _heartbeat() -> dict[str, Any]:
        session = state.current_onboarding_session()
        if session is None:
            raise RuntimeError("Onboarding session closed.")
        updated = _require_backend_client().heartbeat_onboarding_session(session["session_id"])
        state.update_onboarding_session(updated)
        return updated

    state.start_heartbeat(_heartbeat)
