from __future__ import annotations

import argparse
import json
import os
import sys
from dataclasses import replace
from pathlib import Path
from typing import Any

from seller_client_app.backend import BackendClient
from seller_client_app.config import get_settings
from seller_client_app.onboarding import build_phase1_drafts_from_session, summarize_onboarding_session
from seller_client_app.state import (
    append_correction_evidence,
    normalize_runtime_evidence,
    run_minimum_tcp_validation as perform_minimum_tcp_validation,
)


def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--session-file", type=str, default=os.getenv("SELLER_CLIENT_SESSION_FILE"))
    return parser.parse_args()


def _load_session_context(session_file: str | None) -> dict[str, Any]:
    if not session_file:
        raise RuntimeError("SELLER_CLIENT_SESSION_FILE is not set.")
    return json.loads(Path(session_file).read_text(encoding="utf-8"))


def _save_session_context(session_file: str | None, payload: dict[str, Any]) -> None:
    if not session_file:
        raise RuntimeError("SELLER_CLIENT_SESSION_FILE is not set.")
    Path(session_file).write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")


def _backend_client(payload: dict[str, Any]) -> BackendClient:
    settings = replace(
        get_settings(),
        backend_base_url=payload.get("backend_base_url") or get_settings().backend_base_url,
        backend_api_prefix=payload.get("backend_api_prefix") or get_settings().backend_api_prefix,
    )
    return BackendClient(settings, token=payload.get("auth_token"))


def _write_message(message: dict[str, Any]) -> None:
    body = json.dumps(message).encode("utf-8")
    sys.stdout.buffer.write(f"Content-Length: {len(body)}\r\n\r\n".encode("utf-8"))
    sys.stdout.buffer.write(body)
    sys.stdout.buffer.flush()


def _read_message() -> dict[str, Any] | None:
    headers: dict[str, str] = {}
    while True:
        line = sys.stdin.buffer.readline()
        if not line:
            return None
        if line in (b"\r\n", b"\n"):
            break
        key, value = line.decode("utf-8").split(":", 1)
        headers[key.strip().lower()] = value.strip()
    length = int(headers.get("content-length", "0"))
    if length <= 0:
        return None
    body = sys.stdin.buffer.read(length)
    return json.loads(body.decode("utf-8"))


def _tool_result(payload: Any, *, is_error: bool = False) -> dict[str, Any]:
    return {
        "content": [{"type": "text", "text": json.dumps(payload, ensure_ascii=False, indent=2)}],
        "structuredContent": payload if isinstance(payload, dict) else {"result": payload},
        "isError": is_error,
    }


def _tool_descriptors() -> list[dict[str, Any]]:
    return [
        {
            "name": "read_onboarding_state",
            "description": "Read the current seller onboarding session state, manager acceptance, and local browser session metadata.",
            "inputSchema": {"type": "object", "properties": {}, "additionalProperties": False},
        },
        {
            "name": "refresh_onboarding_session",
            "description": "Refresh the onboarding session from the backend and persist the latest state into the local session file.",
            "inputSchema": {"type": "object", "properties": {}, "additionalProperties": False},
        },
        {
            "name": "generate_phase1_probe_drafts",
            "description": "Generate phase-1 probe and join-complete draft payloads from the current onboarding session contract.",
            "inputSchema": {"type": "object", "properties": {}, "additionalProperties": False},
        },
        {
            "name": "submit_linux_host_probe",
            "description": "Submit the Linux host probe using the existing backend seller onboarding contract.",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "reported_phase": {"type": "string"},
                    "host_name": {"type": "string"},
                    "os_name": {"type": "string"},
                    "distribution_name": {"type": "string"},
                    "kernel_release": {"type": "string"},
                    "virtualization_available": {"type": "boolean"},
                    "sudo_available": {"type": "boolean"},
                    "observed_ips": {"type": "array", "items": {"type": "string"}},
                    "notes": {"type": "array", "items": {"type": "string"}},
                    "raw_payload": {"type": "object"},
                },
                "additionalProperties": False,
            },
        },
        {
            "name": "submit_linux_substrate_probe",
            "description": "Submit the Linux substrate probe without exposing free shell access.",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "reported_phase": {"type": "string"},
                    "distribution_name": {"type": "string"},
                    "kernel_release": {"type": "string"},
                    "docker_available": {"type": "boolean"},
                    "docker_version": {"type": "string"},
                    "wireguard_available": {"type": "boolean"},
                    "gpu_available": {"type": "boolean"},
                    "cpu_cores": {"type": "integer"},
                    "memory_gb": {"type": "integer"},
                    "disk_free_gb": {"type": "integer"},
                    "observed_ips": {"type": "array", "items": {"type": "string"}},
                    "observed_wireguard_ip": {"type": "string"},
                    "observed_advertise_addr": {"type": "string"},
                    "observed_data_path_addr": {"type": "string"},
                    "notes": {"type": "array", "items": {"type": "string"}},
                    "raw_payload": {"type": "object"},
                },
                "additionalProperties": False,
            },
        },
        {
            "name": "submit_container_runtime_probe",
            "description": "Submit the container runtime probe using the controlled onboarding write surface.",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "reported_phase": {"type": "string"},
                    "runtime_name": {"type": "string"},
                    "runtime_version": {"type": "string"},
                    "engine_available": {"type": "boolean"},
                    "image_store_accessible": {"type": "boolean"},
                    "network_ready": {"type": "boolean"},
                    "observed_images": {"type": "array", "items": {"type": "string"}},
                    "notes": {"type": "array", "items": {"type": "string"}},
                    "raw_payload": {"type": "object"},
                },
                "additionalProperties": False,
            },
        },
        {
            "name": "submit_join_complete",
            "description": "Submit the flat join-complete ingress required by the backend. Do not send nested runtime-only payloads.",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "reported_phase": {"type": "string"},
                    "node_ref": {"type": "string"},
                    "compute_node_id": {"type": "string"},
                    "observed_wireguard_ip": {"type": "string"},
                    "observed_advertise_addr": {"type": "string"},
                    "observed_data_path_addr": {"type": "string"},
                    "notes": {"type": "array", "items": {"type": "string"}},
                    "raw_payload": {"type": "object"},
                },
                "additionalProperties": False,
            },
        },
        {
            "name": "record_runtime_correction",
            "description": "Persist local correction evidence only. This does not change backend truth or claim manager acceptance.",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "correction_kind": {"type": "string"},
                    "outcome": {"type": "string"},
                    "reported_phase": {"type": "string"},
                    "join_mode": {"type": "string"},
                    "target_host": {"type": "string"},
                    "target_port": {"type": "integer"},
                    "observed_wireguard_ip": {"type": "string"},
                    "observed_advertise_addr": {"type": "string"},
                    "observed_data_path_addr": {"type": "string"},
                    "manager_node_addr_hint": {"type": "string"},
                    "script_path": {"type": "string"},
                    "log_path": {"type": "string"},
                    "rollback_path": {"type": "string"},
                    "notes": {"type": "array", "items": {"type": "string"}},
                    "raw_payload": {"type": "object"},
                },
                "required": ["correction_kind", "outcome"],
                "additionalProperties": False,
            },
        },
        {
            "name": "run_minimum_tcp_validation",
            "description": "Run the local minimum TCP validation against a seller target and persist the probe result only.",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "host": {"type": "string"},
                    "port": {"type": "integer"},
                    "timeout_ms": {"type": "integer"},
                    "validation_kind": {"type": "string"},
                    "source": {"type": "string"},
                    "target_label": {"type": "string"},
                    "notes": {"type": "array", "items": {"type": "string"}},
                    "raw_payload": {"type": "object"},
                },
                "required": ["host", "port"],
                "additionalProperties": False,
            },
        },
        {
            "name": "close_onboarding_session",
            "description": "Close the seller onboarding session from the backend and persist the final state.",
            "inputSchema": {"type": "object", "properties": {}, "additionalProperties": False},
        },
    ]


def _invoke_tool(name: str, arguments: dict[str, Any], payload: dict[str, Any], session_file: str | None) -> dict[str, Any]:
    onboarding = payload.get("onboarding_session")
    backend = _backend_client(payload)

    if name == "read_onboarding_state":
        return {
            "current_user": payload.get("current_user"),
            "window_session": payload.get("window_session"),
            "onboarding_session": summarize_onboarding_session(onboarding),
            "runtime_evidence": normalize_runtime_evidence(payload.get("runtime_evidence")),
            "last_assistant_run": payload.get("last_assistant_run"),
        }

    if onboarding is None:
        raise RuntimeError("Onboarding session is not initialized.")

    session_id = str(onboarding.get("session_id") or "")
    if not session_id:
        raise RuntimeError("Onboarding session id is missing.")

    if name == "refresh_onboarding_session":
        updated = backend.get_onboarding_session(session_id)
        payload["onboarding_session"] = updated
        _save_session_context(session_file, payload)
        return summarize_onboarding_session(updated) or {}

    if name == "generate_phase1_probe_drafts":
        return build_phase1_drafts_from_session(onboarding)

    if name == "submit_linux_host_probe":
        updated = backend.submit_linux_host_probe(session_id, _compact(arguments))
        payload["onboarding_session"] = updated
        _save_session_context(session_file, payload)
        return summarize_onboarding_session(updated) or {}

    if name == "submit_linux_substrate_probe":
        updated = backend.submit_linux_substrate_probe(session_id, _compact(arguments))
        payload["onboarding_session"] = updated
        _save_session_context(session_file, payload)
        return summarize_onboarding_session(updated) or {}

    if name == "submit_container_runtime_probe":
        updated = backend.submit_container_runtime_probe(session_id, _compact(arguments))
        payload["onboarding_session"] = updated
        _save_session_context(session_file, payload)
        return summarize_onboarding_session(updated) or {}

    if name == "submit_join_complete":
        updated = backend.submit_join_complete(session_id, _compact(arguments))
        payload["onboarding_session"] = updated
        _save_session_context(session_file, payload)
        return summarize_onboarding_session(updated) or {}

    if name == "record_runtime_correction":
        runtime_evidence, record = append_correction_evidence(payload.get("runtime_evidence"), _compact(arguments))
        payload["runtime_evidence"] = runtime_evidence
        _save_session_context(session_file, payload)
        return {"correction": record, "runtime_evidence": runtime_evidence}

    if name == "run_minimum_tcp_validation":
        runtime_evidence, record = perform_minimum_tcp_validation(payload.get("runtime_evidence"), _compact(arguments))
        payload["runtime_evidence"] = runtime_evidence
        _save_session_context(session_file, payload)
        return {"validation": record, "runtime_evidence": runtime_evidence}

    if name == "close_onboarding_session":
        updated = backend.close_onboarding_session(session_id)
        payload["onboarding_session"] = updated
        _save_session_context(session_file, payload)
        return summarize_onboarding_session(updated) or {}

    raise RuntimeError(f"Unknown tool: {name}")


def _compact(payload: dict[str, Any]) -> dict[str, Any]:
    return {key: value for key, value in payload.items() if value is not None}


def main() -> None:
    args = _parse_args()
    session_file = args.session_file
    while True:
        message = _read_message()
        if message is None:
            return
        method = message.get("method")
        params = message.get("params") or {}
        message_id = message.get("id")

        if method == "initialize":
            _write_message(
                {
                    "jsonrpc": "2.0",
                    "id": message_id,
                    "result": {
                        "protocolVersion": params.get("protocolVersion", "2024-11-05"),
                        "capabilities": {"tools": {}},
                        "serverInfo": {"name": "seller-client-tools", "version": "0.2.0"},
                    },
                }
            )
            continue

        if method == "notifications/initialized":
            continue

        if method == "ping":
            _write_message({"jsonrpc": "2.0", "id": message_id, "result": {}})
            continue

        if method == "tools/list":
            _write_message({"jsonrpc": "2.0", "id": message_id, "result": {"tools": _tool_descriptors()}})
            continue

        if method == "tools/call":
            name = params.get("name")
            arguments = params.get("arguments") or {}
            try:
                payload = _load_session_context(session_file)
                result = _invoke_tool(name, arguments, payload, session_file)
                body = _tool_result(result, is_error=False)
            except Exception as exc:
                body = _tool_result({"error": str(exc)}, is_error=True)
            _write_message({"jsonrpc": "2.0", "id": message_id, "result": body})
            continue

        _write_message(
            {
                "jsonrpc": "2.0",
                "id": message_id,
                "error": {"code": -32601, "message": f"Method not found: {method}"},
            }
        )


if __name__ == "__main__":
    main()
