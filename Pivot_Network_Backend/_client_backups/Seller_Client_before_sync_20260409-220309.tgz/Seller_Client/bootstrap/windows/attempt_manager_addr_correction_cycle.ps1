param(
  [string]$SessionFilePath = $env:SELLER_CLIENT_SESSION_FILE,
  [ValidateSet("wireguard", "public")]
  [string]$JoinMode = "public",
  [string]$ManagerWireGuardAddress = "10.66.66.1",
  [string]$AdvertiseAddress = "10.66.66.10",
  [string]$DataPathAddress = "10.66.66.10",
  [string]$ListenAddress = "10.66.66.10:2377",
  [int]$PostJoinProbeCount = 30,
  [int]$ProbeIntervalSeconds = 2,
  [string]$ManagerHostNameHint = "docker-desktop",
  [string]$ManagerHostName = "81.70.52.75",
  [string]$ManagerUser = "root",
  [int]$ManagerSshPort = 22,
  [string]$ManagerSshKeyPath = "D:\AI\Pivot_backend_build_team\navi.pem",
  [string]$ManagerMonitorUbuntuDistro = "Ubuntu",
  [int]$ManagerProbeCount = 12,
  [int]$ManagerProbeIntervalSeconds = 5,
  [switch]$SkipOfficialRejoin,
  [switch]$LeaveExistingSwarm,
  [switch]$RemoveStaleDownNodes,
  [int]$MinimumTcpValidationPort = 8080,
  [switch]$SkipBackendAuthoritativeCorrection,
  [switch]$DryRun
)

$ErrorActionPreference = "Stop"
Set-StrictMode -Version Latest
$PSNativeCommandUseErrorActionPreference = $false

if (-not $SessionFilePath) {
  throw "Session file is required. Pass -SessionFilePath or set SELLER_CLIENT_SESSION_FILE."
}
if (-not (Test-Path $SessionFilePath)) {
  throw "Session file not found: $SessionFilePath"
}

$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$rejoinScript = Join-Path $ScriptDir "rejoin_windows_swarm_worker.ps1"
$managerMonitorScript = Join-Path $ScriptDir "monitor_swarm_manager_truth.ps1"
. (Join-Path $ScriptDir "swarm_runtime_common.ps1")

function Capture-Text {
  param([scriptblock]$Command)
  try {
    return (& $Command 2>&1 | Out-String).Trim()
  } catch {
    return ($_ | Out-String).Trim()
  }
}

function Parse-JsonText {
  param([string]$Text)
  if (-not $Text) {
    return $null
  }
  $trimmed = $Text.Trim()
  if (-not $trimmed.StartsWith("{") -and -not $trimmed.StartsWith("[")) {
    return $null
  }
  try {
    return $trimmed | ConvertFrom-Json -Depth 16
  } catch {
    return $null
  }
}

function Invoke-BackendJson {
  param(
    [string]$Method,
    [string]$Url,
    [hashtable]$Headers,
    [object]$Body = $null
  )

  $jsonBody = $null
  if ($null -ne $Body) {
    $jsonBody = $Body | ConvertTo-Json -Depth 16 -Compress
  }

  try {
    $response = Invoke-WebRequest -UseBasicParsing -Uri $Url -Method $Method -Headers $Headers -Body $jsonBody -ContentType "application/json"
    return [PSCustomObject]@{
      ok = $true
      status_code = [int]$response.StatusCode
      payload = Parse-JsonText -Text $response.Content
      raw = $response.Content
      error = $null
    }
  } catch {
    $statusCode = $null
    $raw = $null
    if ($_.Exception.Response) {
      try {
        $statusCode = [int]$_.Exception.Response.StatusCode
      } catch {
        $statusCode = $null
      }
      try {
        $stream = $_.Exception.Response.GetResponseStream()
        if ($null -ne $stream) {
          $reader = New-Object System.IO.StreamReader($stream)
          $raw = $reader.ReadToEnd()
          $reader.Dispose()
        }
      } catch {
        $raw = $null
      }
    }
    return [PSCustomObject]@{
      ok = $false
      status_code = $statusCode
      payload = Parse-JsonText -Text $raw
      raw = $raw
      error = $_.Exception.Message
    }
  }
}

function Get-CompactSessionSummary {
  param($SessionPayload)
  if ($null -eq $SessionPayload) {
    return $null
  }
  return [ordered]@{
    session_id = $SessionPayload.session_id
    status = $SessionPayload.status
    expected_wireguard_ip = $SessionPayload.expected_wireguard_ip
    last_join_complete = $SessionPayload.last_join_complete
    manager_acceptance = $SessionPayload.manager_acceptance
    effective_target_addr = $SessionPayload.effective_target_addr
    effective_target_source = $SessionPayload.effective_target_source
    truth_authority = $SessionPayload.truth_authority
    correction_history_count = @($SessionPayload.correction_history).Count
    minimum_tcp_validation = $SessionPayload.minimum_tcp_validation
  }
}

function Get-ManagerSelectedCandidate {
  param(
    $ManagerMonitorPayload
  )

  if ($null -eq $ManagerMonitorPayload) {
    return $null
  }
  if ($null -ne $ManagerMonitorPayload.latest_sample -and $null -ne $ManagerMonitorPayload.latest_sample.selected_candidate) {
    return $ManagerMonitorPayload.latest_sample.selected_candidate
  }
  return $null
}

function Get-TcpValidationPayload {
  param(
    [string]$TargetAddress,
    [int]$TargetPort,
    [string]$TruthAuthority,
    [string]$EffectiveTargetSource
  )

  $probe = Test-TcpPort -TargetHost $TargetAddress -Port $TargetPort
  return [PSCustomObject]@{
    probe = $probe
    backend_payload = [ordered]@{
      reported_phase = "repair"
      target_addr = $TargetAddress
      target_port = $TargetPort
      reachable = [bool]$probe.reachable
      notes = @(
        "minimum TCP validation submitted from attempt_manager_addr_correction_cycle",
        "truth_authority=$TruthAuthority",
        "effective_target_source=$EffectiveTargetSource"
      )
      raw_payload = @{
        source_surface = "attempt_manager_addr_correction_cycle"
        tcp_probe = $probe
      }
    }
  }
}

function Exit-WithFailure {
  param(
    [string]$Step,
    [hashtable]$Payload
  )

  $body = [ordered]@{
    step = $Step
    session_id = $sessionId
  }
  foreach ($entry in $Payload.GetEnumerator()) {
    $body[$entry.Key] = $entry.Value
  }
  $body | ConvertTo-Json -Depth 12
  exit 1
}

$session = Get-Content -Raw $SessionFilePath | ConvertFrom-Json
$onboardingSession = $session.onboarding_session
if ($null -eq $onboardingSession) {
  throw "onboarding_session is missing from session file."
}

$sessionId = [string]$onboardingSession.session_id
$computeNodeId = [string]$onboardingSession.requested_compute_node_id
$backendBaseUrl = [string]$session.backend_base_url
$backendApiPrefix = [string]$session.backend_api_prefix
$authToken = [string]$session.auth_token

if (-not $sessionId) {
  throw "session_id is missing from session file."
}
if (-not $backendBaseUrl) {
  throw "backend_base_url is missing from session file."
}
if (-not $backendApiPrefix) {
  throw "backend_api_prefix is missing from session file."
}
if (-not $authToken) {
  throw "auth_token is missing from session file."
}

$headers = @{
  Authorization = "Bearer $authToken"
}

$joinCompleteUrl = "$backendBaseUrl$backendApiPrefix/seller/onboarding/sessions/$sessionId/join-complete"
$correctionUrl = "$backendBaseUrl$backendApiPrefix/seller/onboarding/sessions/$sessionId/corrections"
$reverifyUrl = "$backendBaseUrl$backendApiPrefix/seller/onboarding/sessions/$sessionId/re-verify"
$authoritativeUrl = "$backendBaseUrl$backendApiPrefix/seller/onboarding/sessions/$sessionId/authoritative-effective-target"
$tcpValidationUrl = "$backendBaseUrl$backendApiPrefix/seller/onboarding/sessions/$sessionId/minimum-tcp-validation"
$sessionUrl = "$backendBaseUrl$backendApiPrefix/seller/onboarding/sessions/$sessionId"

$joinCommand = @(
  "-NoProfile",
  "-ExecutionPolicy", "Bypass",
  "-File", $rejoinScript,
  "-SessionFilePath", $SessionFilePath,
  "-JoinMode", $JoinMode,
  "-ManagerWireGuardAddress", $ManagerWireGuardAddress,
  "-AdvertiseAddress", $AdvertiseAddress,
  "-DataPathAddress", $DataPathAddress,
  "-PostJoinProbeCount", [string]$PostJoinProbeCount,
  "-ProbeIntervalSeconds", [string]$ProbeIntervalSeconds
)
if ($ListenAddress) {
  $joinCommand += @("-ListenAddress", $ListenAddress)
}
if ($LeaveExistingSwarm) {
  $joinCommand += "-LeaveExistingSwarm"
}

$monitorCommand = @(
  "-NoProfile",
  "-ExecutionPolicy", "Bypass",
  "-File", $managerMonitorScript,
  "-SessionFilePath", $SessionFilePath,
  "-ComputeNodeId", $computeNodeId,
  "-ExpectedWireGuardAddress", $AdvertiseAddress,
  "-HostNameHint", $ManagerHostNameHint,
  "-ManagerHostName", $ManagerHostName,
  "-ManagerUser", $ManagerUser,
  "-ManagerSshPort", [string]$ManagerSshPort,
  "-ManagerSshKeyPath", $ManagerSshKeyPath,
  "-UbuntuDistro", $ManagerMonitorUbuntuDistro,
  "-ProbeCount", [string]$ManagerProbeCount,
  "-ProbeIntervalSeconds", [string]$ManagerProbeIntervalSeconds
)
if ($RemoveStaleDownNodes) {
  $monitorCommand += "-RemoveStaleDownNodes"
}

if ($DryRun) {
  [PSCustomObject]@{
    session_file = $SessionFilePath
    session_id = $sessionId
    join_mode = $JoinMode
    join_command = @("powershell.exe") + $joinCommand
    manager_monitor_command = @("powershell.exe") + $monitorCommand
    join_complete_url = $joinCompleteUrl
    correction_url = $correctionUrl
    reverify_url = $reverifyUrl
    authoritative_effective_target_url = $authoritativeUrl
    minimum_tcp_validation_url = $tcpValidationUrl
    skip_official_rejoin = [bool]$SkipOfficialRejoin
    leave_existing_swarm = [bool]$LeaveExistingSwarm
  } | ConvertTo-Json -Depth 10
  exit 0
}

$joinRaw = $null
$joinExitCode = 0
$joinPayload = $null
if ($SkipOfficialRejoin) {
  $currentSwarmRaw = Capture-Text { docker info --format "{{json .Swarm}}" }
  $joinPayload = [PSCustomObject]@{
    session_file = $SessionFilePath
    join_mode = $JoinMode
    join_target = if ($JoinMode -eq "wireguard") { "${ManagerWireGuardAddress}:2377" } else { $null }
    join_exit_code = 0
    leave_existing_swarm = [bool]$LeaveExistingSwarm
    join_output = "skipped official rejoin because current swarm state is already active and seller-side WG path is established"
    before_state = $currentSwarmRaw
    after_state = $currentSwarmRaw
    docker_desktop_route_to_manager = $null
    before_snapshot = $null
    after_snapshot = $null
    post_join_samples = @()
  }
} else {
  $joinRaw = Capture-Text { & powershell.exe @joinCommand }
  $joinExitCode = $LASTEXITCODE
  $joinPayload = Parse-JsonText -Text $joinRaw
  if ($joinExitCode -ne 0) {
    Exit-WithFailure -Step "join_failed" -Payload @{
      join_exit_code = $joinExitCode
      join_result = $joinPayload
      join_raw = $joinRaw
    }
  }
}

$swarmInfoText = Capture-Text { docker info --format "{{json .Swarm}}" }
$swarmInfo = Parse-JsonText -Text $swarmInfoText
$nodeRef = $null
$observedWireGuardIp = $AdvertiseAddress
if ($null -ne $swarmInfo) {
  $nodeRef = [string]$swarmInfo.NodeID
  if ($swarmInfo.NodeAddr) {
    $observedWireGuardIp = [string]$swarmInfo.NodeAddr
  }
}

$joinCompletePayload = [ordered]@{
  reported_phase = "repair"
  node_ref = if ($nodeRef) { $nodeRef } else { $null }
  compute_node_id = if ($computeNodeId) { $computeNodeId } else { $null }
  observed_wireguard_ip = $observedWireGuardIp
  observed_advertise_addr = $AdvertiseAddress
  observed_data_path_addr = $DataPathAddress
  notes = @(
    "manager addr correction cycle after live join",
    "official WG-target rejoin executed before join-complete submission"
  )
  raw_payload = @{
    join_mode = $JoinMode
    join_result = $joinPayload
  }
}

$joinCompleteResponse = Invoke-BackendJson -Method "POST" -Url $joinCompleteUrl -Headers $headers -Body $joinCompletePayload
if (-not $joinCompleteResponse.ok) {
  Exit-WithFailure -Step "join_complete_failed" -Payload @{
    join_result = $joinPayload
    join_complete = $joinCompleteResponse
  }
}

if ($nodeRef) {
  $monitorCommand += @("-NodeRef", $nodeRef)
}
$managerMonitorRaw = Capture-Text { & powershell.exe @monitorCommand }
$managerMonitorExitCode = $LASTEXITCODE
$managerMonitor = Parse-JsonText -Text $managerMonitorRaw
if ($managerMonitorExitCode -ne 0 -or $null -eq $managerMonitor) {
  Exit-WithFailure -Step "manager_truth_monitor_failed" -Payload @{
    join_result = $joinPayload
    join_complete = $joinCompleteResponse
    manager_monitor_exit_code = $managerMonitorExitCode
    manager_monitor_raw = $managerMonitorRaw
    manager_monitor = $managerMonitor
  }
}

$managerSelectedCandidate = Get-ManagerSelectedCandidate -ManagerMonitorPayload $managerMonitor

$correctionResponse = $null
if (-not $managerMonitor.raw_success) {
  $correctionPayload = [ordered]@{
    reported_phase = "repair"
    source_surface = "runtime_manager_addr_correction_cycle"
    correction_action = "set_explicit_advertise_and_data_path_addr_after_live_join"
    target_wireguard_ip = $observedWireGuardIp
    observed_advertise_addr = $AdvertiseAddress
    observed_data_path_addr = $DataPathAddress
    notes = @(
      "official WG-target rejoin completed but manager raw truth still not converged",
      "recording runtime correction before backend re-verify"
    )
    raw_payload = @{
      join_mode = $JoinMode
      node_ref = $nodeRef
      compute_node_id = $computeNodeId
      docker_swarm = $swarmInfo
      manager_monitor = $managerMonitor
    }
  }

  $correctionResponse = Invoke-BackendJson -Method "POST" -Url $correctionUrl -Headers $headers -Body $correctionPayload
  if (-not $correctionResponse.ok) {
    Exit-WithFailure -Step "correction_failed" -Payload @{
      join_result = $joinPayload
      join_complete = $joinCompleteResponse
      manager_monitor = $managerMonitor
      correction = $correctionResponse
    }
  }
}

$reverifyNodeRef = if ($null -ne $managerSelectedCandidate -and $managerSelectedCandidate.id) {
  [string]$managerSelectedCandidate.id
} elseif ($nodeRef) {
  $nodeRef
} else {
  $null
}

$reverifyPayload = [ordered]@{
  reported_phase = "repair"
  node_ref = $reverifyNodeRef
  compute_node_id = if ($computeNodeId) { $computeNodeId } else { $null }
  notes = @(
    "manager reverify after operator correction cycle",
    "raw_success=$($managerMonitor.raw_success)"
  )
  raw_payload = @{
    manager_monitor = $managerMonitor
  }
}

$reverifyResponse = Invoke-BackendJson -Method "POST" -Url $reverifyUrl -Headers $headers -Body $reverifyPayload
if (-not $reverifyResponse.ok) {
  Exit-WithFailure -Step "reverify_failed" -Payload @{
    join_result = $joinPayload
    manager_monitor = $managerMonitor
    reverify = $reverifyResponse
  }
}

$finalSessionResponse = Invoke-BackendJson -Method "GET" -Url $sessionUrl -Headers $headers
if (-not $finalSessionResponse.ok) {
  Exit-WithFailure -Step "session_get_failed" -Payload @{
    reverify = $reverifyResponse
    final_session = $finalSessionResponse
  }
}

$authoritativeCorrectionResponse = $null
if ($finalSessionResponse.payload.manager_acceptance.status -ne "matched" -and -not $SkipBackendAuthoritativeCorrection) {
  $authoritativeCorrectionResponse = Invoke-BackendJson -Method "POST" `
    -Url $authoritativeUrl `
    -Headers $headers `
    -Body ([ordered]@{
      reported_phase = "repair"
      source_surface = "backend_authoritative_workflow"
      effective_target_addr = $AdvertiseAddress
      effective_target_reason = "fresh Windows WG-target rejoin evidence plus manager raw truth mismatch"
      notes = @(
        "formal backend authoritative correction after fresh runtime rejoin evidence",
        "manager raw truth retained separately in manager_acceptance"
      )
      raw_payload = @{
        expected_wireguard_ip = $AdvertiseAddress
        join_complete = $joinCompleteResponse.payload
        manager_monitor = $managerMonitor
      }
    })
  if (-not $authoritativeCorrectionResponse.ok) {
    Exit-WithFailure -Step "authoritative_effective_target_failed" -Payload @{
      reverify = $reverifyResponse
      authoritative_effective_target = $authoritativeCorrectionResponse
    }
  }
  $finalSessionResponse = Invoke-BackendJson -Method "GET" -Url $sessionUrl -Headers $headers
  if (-not $finalSessionResponse.ok) {
    Exit-WithFailure -Step "session_get_failed_after_authoritative_target" -Payload @{
      authoritative_effective_target = $authoritativeCorrectionResponse
      final_session = $finalSessionResponse
    }
  }
}

$validationTarget = $null
if ($finalSessionResponse.payload.effective_target_addr) {
  $validationTarget = [string]$finalSessionResponse.payload.effective_target_addr
} elseif ($finalSessionResponse.payload.manager_acceptance.status -eq "matched") {
  $validationTarget = [string]$finalSessionResponse.payload.manager_acceptance.observed_manager_node_addr
}

$tcpValidationLocalProbe = $null
$tcpValidationResponse = $null
if ($validationTarget) {
  $truthAuthority = [string]$finalSessionResponse.payload.truth_authority
  $effectiveTargetSource = [string]$finalSessionResponse.payload.effective_target_source
  $tcpValidationLocalProbe = Get-TcpValidationPayload `
    -TargetAddress $validationTarget `
    -TargetPort $MinimumTcpValidationPort `
    -TruthAuthority $truthAuthority `
    -EffectiveTargetSource $effectiveTargetSource
  $tcpValidationResponse = Invoke-BackendJson -Method "POST" `
    -Url $tcpValidationUrl `
    -Headers $headers `
    -Body $tcpValidationLocalProbe.backend_payload
  if (-not $tcpValidationResponse.ok) {
    Exit-WithFailure -Step "minimum_tcp_validation_failed" -Payload @{
      final_session = $finalSessionResponse
      minimum_tcp_validation = $tcpValidationResponse
      local_probe = $tcpValidationLocalProbe.probe
    }
  }
  $finalSessionResponse = Invoke-BackendJson -Method "GET" -Url $sessionUrl -Headers $headers
  if (-not $finalSessionResponse.ok) {
    Exit-WithFailure -Step "session_get_failed_after_minimum_tcp_validation" -Payload @{
      minimum_tcp_validation = $tcpValidationResponse
      final_session = $finalSessionResponse
    }
  }
}

$pathOutcome = "incomplete"
if ($finalSessionResponse.payload.manager_acceptance.status -eq "matched" -and `
    $null -ne $finalSessionResponse.payload.minimum_tcp_validation -and `
    $finalSessionResponse.payload.minimum_tcp_validation.validated_against_manager_target -and `
    $finalSessionResponse.payload.minimum_tcp_validation.reachable) {
  $pathOutcome = "raw_success"
} elseif ($finalSessionResponse.payload.truth_authority -eq "backend_correction" -and `
    $null -ne $finalSessionResponse.payload.minimum_tcp_validation -and `
    $finalSessionResponse.payload.minimum_tcp_validation.validated_against_effective_target -and `
    $finalSessionResponse.payload.minimum_tcp_validation.reachable) {
  $pathOutcome = "backend_authoritative_success"
}

[PSCustomObject]@{
  session_id = $sessionId
  join_result = $joinPayload
  docker_swarm = $swarmInfo
  join_complete = @{
    ok = $joinCompleteResponse.ok
    status_code = $joinCompleteResponse.status_code
    session = Get-CompactSessionSummary -SessionPayload $joinCompleteResponse.payload
  }
  manager_monitor = @{
    exit_code = $managerMonitorExitCode
    raw_success = $managerMonitor.raw_success
    latest_sample = $managerMonitor.latest_sample
  }
  correction = @{
    ok = if ($null -ne $correctionResponse) { $correctionResponse.ok } else { $null }
    status_code = if ($null -ne $correctionResponse) { $correctionResponse.status_code } else { $null }
    session = if ($null -ne $correctionResponse) {
      Get-CompactSessionSummary -SessionPayload $correctionResponse.payload
    } else {
      $null
    }
  }
  reverify = @{
    ok = $reverifyResponse.ok
    status_code = $reverifyResponse.status_code
    session = Get-CompactSessionSummary -SessionPayload $reverifyResponse.payload
  }
  authoritative_effective_target = @{
    ok = if ($null -ne $authoritativeCorrectionResponse) { $authoritativeCorrectionResponse.ok } else { $null }
    status_code = if ($null -ne $authoritativeCorrectionResponse) { $authoritativeCorrectionResponse.status_code } else { $null }
    session = if ($null -ne $authoritativeCorrectionResponse) {
      Get-CompactSessionSummary -SessionPayload $authoritativeCorrectionResponse.payload
    } else {
      $null
    }
  }
  minimum_tcp_validation = @{
    attempted = [bool]$validationTarget
    validation_target = $validationTarget
    local_probe = if ($null -ne $tcpValidationLocalProbe) { $tcpValidationLocalProbe.probe } else { $null }
    ok = if ($null -ne $tcpValidationResponse) { $tcpValidationResponse.ok } else { $null }
    status_code = if ($null -ne $tcpValidationResponse) { $tcpValidationResponse.status_code } else { $null }
    session = if ($null -ne $tcpValidationResponse) {
      Get-CompactSessionSummary -SessionPayload $tcpValidationResponse.payload
    } else {
      $null
    }
  }
  final_session = @{
    ok = $finalSessionResponse.ok
    status_code = $finalSessionResponse.status_code
    session = Get-CompactSessionSummary -SessionPayload $finalSessionResponse.payload
  }
  summary = @{
    path_outcome = $pathOutcome
    manager_acceptance_status = $finalSessionResponse.payload.manager_acceptance.status
    observed_manager_node_addr = $finalSessionResponse.payload.manager_acceptance.observed_manager_node_addr
    effective_target_addr = $finalSessionResponse.payload.effective_target_addr
    effective_target_source = $finalSessionResponse.payload.effective_target_source
    truth_authority = $finalSessionResponse.payload.truth_authority
    minimum_tcp_validation = $finalSessionResponse.payload.minimum_tcp_validation
  }
} | ConvertTo-Json -Depth 12
