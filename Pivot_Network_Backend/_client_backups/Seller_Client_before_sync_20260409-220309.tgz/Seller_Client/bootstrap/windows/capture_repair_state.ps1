param(
  [string]$OutputRoot = "D:\AI\Pivot_Client\seller_client\rollback",
  [string]$HostTunnelName = "wg-seller",
  [string]$UbuntuDistro = "Ubuntu"
)

$ErrorActionPreference = "Stop"
Set-StrictMode -Version Latest

$PSNativeCommandUseErrorActionPreference = $false

$stamp = Get-Date -Format "yyyyMMddHHmmss"
$outputDir = Join-Path $OutputRoot $stamp
New-Item -ItemType Directory -Force $outputDir | Out-Null

$hostTunnelService = 'WireGuardTunnel$' + $HostTunnelName
$dockerDesktopNetworkPath = Join-Path $outputDir "docker-desktop-network.txt"
$ubuntuNetworkPath = Join-Path $outputDir "ubuntu-network.txt"

function Capture-CommandOutput {
  param(
    [string]$Path,
    [scriptblock]$Command
  )

  try {
    (& $Command 2>&1 | Out-String) | Set-Content -Path $Path -Encoding UTF8
  } catch {
    ($_ | Out-String) | Set-Content -Path $Path -Encoding UTF8
  }
}

Capture-CommandOutput -Path (Join-Path $outputDir "$HostTunnelName.conf") -Command { wg showconf $HostTunnelName }
Capture-CommandOutput -Path (Join-Path $outputDir "wg-show.txt") -Command { wg show }
Capture-CommandOutput -Path (Join-Path $outputDir "docker-contexts.jsonl") -Command { docker context ls --format "{{json .}}" }
Capture-CommandOutput -Path (Join-Path $outputDir "docker-desktop-swarm.json") -Command { docker info --format "{{json .Swarm}}" }
wsl.exe -l -v | Set-Content -Path (Join-Path $outputDir "wsl-list.txt") -Encoding UTF8
Capture-CommandOutput -Path $dockerDesktopNetworkPath -Command { wsl.exe -d docker-desktop sh -lc "ip addr; echo ---; ip route" }
Capture-CommandOutput -Path $ubuntuNetworkPath -Command { wsl.exe -d $UbuntuDistro sh -lc "ip addr; echo ---; ip route" }
Get-NetIPAddress | Where-Object { $_.IPAddress -like "10.66.66.*" } |
  Select-Object InterfaceAlias, IPAddress, PrefixLength, AddressFamily |
  ConvertTo-Json -Depth 4 |
  Set-Content -Path (Join-Path $outputDir "windows-addresses.json") -Encoding UTF8
Get-Service com.docker.service, $hostTunnelService -ErrorAction SilentlyContinue |
  Select-Object Status, Name, DisplayName |
  ConvertTo-Json -Depth 4 |
  Set-Content -Path (Join-Path $outputDir "windows-services.json") -Encoding UTF8

[PSCustomObject]@{
  output_dir = $outputDir
  host_tunnel_name = $HostTunnelName
  ubuntu_distro = $UbuntuDistro
  current_default_route = "Windows seller agent + overlay identity + local runtime"
  historical_wsl_route = "Historical WSL substrate diagnostics"
  artifacts = @(
    "$HostTunnelName.conf",
    "wg-show.txt",
    "docker-contexts.jsonl",
    "docker-desktop-swarm.json",
    "wsl-list.txt",
    "docker-desktop-network.txt",
    "ubuntu-network.txt",
    "windows-addresses.json",
    "windows-services.json"
  )
} | ConvertTo-Json -Depth 4
