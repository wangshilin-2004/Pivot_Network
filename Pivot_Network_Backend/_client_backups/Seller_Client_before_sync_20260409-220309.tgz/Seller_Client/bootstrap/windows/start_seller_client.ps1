param(
  [switch]$DryRun
)

$ErrorActionPreference = "Stop"
Set-StrictMode -Version Latest

$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$ProjectRoot = Split-Path -Parent (Split-Path -Parent $ScriptDir)
$SharedRoot = Split-Path -Parent $ProjectRoot
$VenvDir = Join-Path $ProjectRoot ".venv"
$VenvPython = Join-Path $VenvDir "Scripts\python.exe"
$CodexConfigTemplatePath = Join-Path $SharedRoot "env_setup_and_install\codex.config.toml"

function Resolve-Python {
  if (Test-Path $VenvPython) {
    return $VenvPython
  }
  $python = Get-Command python -ErrorAction SilentlyContinue
  if ($python) {
    return $python.Source
  }
  $py = Get-Command py -ErrorAction SilentlyContinue
  if ($py) {
    return $py.Source
  }
  throw "Python 3.11+ not found on PATH."
}

$BootstrapPython = Resolve-Python
$Port = if ($env:SELLER_CLIENT_APP_PORT) { $env:SELLER_CLIENT_APP_PORT } else { "8901" }
$BackendBaseUrl = if ($env:SELLER_CLIENT_BACKEND_BASE_URL) { $env:SELLER_CLIENT_BACKEND_BASE_URL } else { "https://pivotcompute.store" }

if ($DryRun) {
  [PSCustomObject]@{
    bootstrap_script = $MyInvocation.MyCommand.Path
    project_root = $ProjectRoot
    shared_root = $SharedRoot
    bootstrap_python = $BootstrapPython
    venv_dir = $VenvDir
    venv_exists = (Test-Path $VenvDir)
    codex_config_template_path = $CodexConfigTemplatePath
    codex_config_template_exists = (Test-Path $CodexConfigTemplatePath)
    port = $Port
    backend_base_url = $BackendBaseUrl
  } | ConvertTo-Json -Depth 3
  exit 0
}

if (-not (Test-Path $VenvPython)) {
  & $BootstrapPython -m venv $VenvDir
}

& $VenvPython -m pip install --upgrade pip
& $VenvPython -m pip install -e $ProjectRoot

if (Test-Path $CodexConfigTemplatePath) {
  $env:SELLER_CLIENT_CODEX_CONFIG_TEMPLATE_PATH = $CodexConfigTemplatePath
}

$Listeners = Get-NetTCPConnection -LocalPort $Port -State Listen -ErrorAction SilentlyContinue
foreach ($Listener in $Listeners) {
  Stop-Process -Id $Listener.OwningProcess -Force -ErrorAction SilentlyContinue
}

$Command = "set SELLER_CLIENT_BACKEND_BASE_URL=$BackendBaseUrl&& set SELLER_CLIENT_CODEX_CONFIG_TEMPLATE_PATH=$CodexConfigTemplatePath&& cd /d `"$ProjectRoot`" && `"$VenvPython`" -m uvicorn seller_client_app.main:app --host 127.0.0.1 --port $Port"
Start-Process -FilePath "cmd.exe" -ArgumentList "/c", $Command -WorkingDirectory $ProjectRoot

Start-Sleep -Seconds 2
try {
  Start-Process "http://127.0.0.1:$Port/"
} catch {
  Write-Warning "Browser launch skipped: $($_.Exception.Message)"
}

Write-Output "Pivot Seller Client started on http://127.0.0.1:$Port/"
