from __future__ import annotations

import json
import socket
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from seller_client_app.mcp_server import _invoke_tool, _load_session_context, _tool_descriptors


def sample_session_payload() -> dict[str, object]:
    return {
        "backend_base_url": "https://pivotcompute.store",
        "backend_api_prefix": "/api/v1",
        "auth_token": "token-1",
        "current_user": {"id": "user-1", "email": "seller@example.com"},
        "window_session": {"session_id": "window-1"},
        "last_assistant_run": None,
        "onboarding_session": {
            "session_id": "join-session-0001",
            "seller_user_id": "seller-user-0001",
            "status": "issued",
            "requested_offer_tier": "medium",
            "requested_accelerator": "gpu",
            "requested_compute_node_id": "compute-seller-1",
            "swarm_join_material": {
                "manager_addr": "81.70.52.75",
                "manager_port": 2377,
                "swarm_join_command": "docker swarm join --token join-token-1 81.70.52.75:2377",
                "recommended_compute_node_id": "compute-seller-1",
                "registry_host": "registry.example.com",
                "registry_port": 5000,
                "recommended_labels": {
                    "platform.role": "compute",
                    "platform.compute_node_id": "compute-seller-1",
                    "platform.seller_user_id": "seller-user-0001",
                },
            },
            "required_labels": {
                "platform.role": "compute",
                "platform.compute_node_id": "compute-seller-1",
                "platform.seller_user_id": "seller-user-0001",
            },
            "expected_wireguard_ip": "10.0.8.12",
            "probe_summary": None,
            "container_runtime_probe": None,
            "last_join_complete": None,
            "manager_acceptance": {"status": "pending"},
        },
    }


class FakeBackend:
    def __init__(self) -> None:
        self.updated_payload = {
            **sample_session_payload()["onboarding_session"],
            "status": "verified",
            "last_join_complete": {"compute_node_id": "compute-seller-1"},
        }

    def get_onboarding_session(self, session_id: str) -> dict[str, object]:
        assert session_id == "join-session-0001"
        return dict(self.updated_payload)

    def submit_join_complete(self, session_id: str, payload: dict[str, object]) -> dict[str, object]:
        assert session_id == "join-session-0001"
        assert payload["compute_node_id"] == "compute-seller-1"
        return dict(self.updated_payload)


class McpServerTests(unittest.TestCase):
    def test_tool_descriptors_only_expose_controlled_actions(self) -> None:
        names = {tool["name"] for tool in _tool_descriptors()}

        self.assertIn("read_onboarding_state", names)
        self.assertIn("refresh_onboarding_session", names)
        self.assertIn("generate_phase1_probe_drafts", names)
        self.assertIn("submit_linux_host_probe", names)
        self.assertIn("submit_join_complete", names)
        self.assertIn("record_runtime_correction", names)
        self.assertIn("run_minimum_tcp_validation", names)
        self.assertNotIn("shell", names)
        self.assertNotIn("run_command", names)

    def test_generate_drafts_and_submit_join_complete_persist_session_file(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            session_file = Path(tmpdir) / "session.json"
            session_file.write_text(json.dumps(sample_session_payload()), encoding="utf-8")
            payload = _load_session_context(str(session_file))
            backend = FakeBackend()

            with patch("seller_client_app.mcp_server._backend_client", return_value=backend):
                drafts = _invoke_tool("generate_phase1_probe_drafts", {}, payload, str(session_file))
                self.assertIn("write_payloads", drafts)
                self.assertIn("join_complete", drafts["write_payloads"])

                result = _invoke_tool(
                    "submit_join_complete",
                    {"compute_node_id": "compute-seller-1"},
                    payload,
                    str(session_file),
                )
                self.assertEqual(result["status"], "verified")

            persisted = json.loads(session_file.read_text(encoding="utf-8"))
            self.assertEqual(persisted["onboarding_session"]["status"], "verified")
            self.assertEqual(
                persisted["onboarding_session"]["last_join_complete"]["compute_node_id"],
                "compute-seller-1",
            )

    def test_record_runtime_correction_and_tcp_validation_persist_session_file(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            session_file = Path(tmpdir) / "session.json"
            session_file.write_text(json.dumps(sample_session_payload()), encoding="utf-8")
            payload = _load_session_context(str(session_file))

            correction = _invoke_tool(
                "record_runtime_correction",
                {
                    "correction_kind": "advertise_override",
                    "outcome": "succeeded",
                    "reported_phase": "repair",
                    "script_path": "Seller_Client/scripts/rejoin-windows-swarm.sh",
                    "notes": ["recorded locally only"],
                },
                payload,
                str(session_file),
            )
            self.assertEqual(correction["correction"]["correction_kind"], "advertise_override")
            self.assertEqual(correction["runtime_evidence"]["latest_correction"]["outcome"], "succeeded")

            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as listener:
                listener.bind(("127.0.0.1", 0))
                listener.listen(1)
                host, port = listener.getsockname()
                validation = _invoke_tool(
                    "run_minimum_tcp_validation",
                    {
                        "host": host,
                        "port": port,
                        "target_label": "corrected_seller_target",
                    },
                    payload,
                    str(session_file),
                )

            self.assertTrue(validation["validation"]["reachable"])
            persisted = json.loads(session_file.read_text(encoding="utf-8"))
            runtime_evidence = persisted["runtime_evidence"]
            self.assertEqual(len(runtime_evidence["correction_history"]), 1)
            self.assertEqual(len(runtime_evidence["tcp_validations"]), 1)
            self.assertEqual(runtime_evidence["latest_correction"]["correction_kind"], "advertise_override")
            self.assertTrue(runtime_evidence["latest_tcp_validation"]["reachable"])
