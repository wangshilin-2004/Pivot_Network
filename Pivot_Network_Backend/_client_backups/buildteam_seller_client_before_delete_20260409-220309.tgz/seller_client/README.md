# Pivot Seller Client

Windows 卖家本地客户端现在收束成一条正式主线：

- `bootstrap/windows/install_and_check_seller_client.ps1`
  - 正式安装 / 环境检查入口
  - 负责 venv、依赖安装、健康报告生成、半自动修复
- `bootstrap/windows/start_seller_client.ps1`
  - 正式启动入口
  - 只负责启动本地 Web 壳，不再承担安装和修复

应用主线位于 `seller_client_app/`：

- `main.py`
  - 本地 FastAPI Web 壳
- `local_system.py`
  - 环境检查、半自动修复、诊断包导出、标准 Windows workflow 调用
- `mcp_server.py`
  - session-scoped MCP server
- `backend.py`
  - 本地客户端到后端的统一 API 边界

当前公开工作区固定为 5 个：

- `环境`
- `网络 / WireGuard`
- `Docker / Swarm`
- `接入会话`
- `AI 助手`

历史排障脚本不会继续作为正式入口使用。需要保留的旧脚本会归档到 `bootstrap/windows/legacy/`，实验性内部 runner 只作为受控实现细节保留。
