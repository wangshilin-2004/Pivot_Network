# Seller Client Docs

Active documents in this folder describe the current Windows seller-client shape and the supported MVP workflow.

Use these files first:

- `phase1-bootstrap-contract.md`
  - Phase 1 bootstrap contract and environment/install expectations.
- `seller-overlay-connectivity-architecture-cn.md`
  - Overlay and seller connectivity architecture notes.
- `windows-docker-desktop-swarm-wireguard-analysis-cn.md`
  - Current Swarm/WireGuard behavior analysis.
- `windows-seller-client-current-status-and-server-sync-2026-04-09.md`
  - Latest implementation status, sync note, and next-step objective.

Archived investigation handoff notes live under `docs/archive/`.
