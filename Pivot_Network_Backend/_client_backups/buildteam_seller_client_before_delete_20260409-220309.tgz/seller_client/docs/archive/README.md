# Archived Docs

This directory contains historical Phase 2B handoff notes, retry logs, and one-off investigations.

These files are intentionally kept out of the active docs surface because they describe intermediate debugging states rather than the current supported client workflow.

For the current product shape, start from:

- `../README.md`
- `../windows-seller-client-current-status-and-server-sync-2026-04-09.md`
