$script:LinuxEnginePipe = "\\.\pipe\dockerDesktopLinuxEngine"

function Convert-ToWslPath {
  param([string]$WindowsPath)

  $fullPath = [System.IO.Path]::GetFullPath($WindowsPath)
  $drive = $fullPath.Substring(0, 1).ToLowerInvariant()
  $rest = $fullPath.Substring(2).Replace("\", "/")
  return "/mnt/$drive$rest"
}

function Normalize-CapturedText {
  param([string]$Text)

  if ($null -eq $Text) {
    return ""
  }

  $clean = $Text -replace "`0", ""
  $lines = $clean -split "`r?`n" | ForEach-Object { $_.TrimEnd() }
  $filtered = $lines | Where-Object {
    $_ -and
    $_ -notmatch '^\s*wsl:'
  }
  return ($filtered -join "`n").Trim()
}

function Get-DockerCliPath {
  $command = Get-Command docker.exe -ErrorAction SilentlyContinue
  if ($null -ne $command -and $command.Source) {
    return [string]$command.Source
  }

  $candidates = @(
    (Join-Path ${env:ProgramFiles} "Docker\Docker\resources\bin\docker.exe"),
    (Join-Path ${env:ProgramW6432} "Docker\Docker\resources\bin\docker.exe"),
    "C:\Program Files\Docker\Docker\resources\bin\docker.exe"
  ) | Select-Object -Unique

  foreach ($candidate in $candidates) {
    if ($candidate -and (Test-Path $candidate)) {
      return [string]$candidate
    }
  }

  throw "docker.exe was not found on PATH or in the standard Docker Desktop install directory."
}

function Convert-ToNativeArgumentString {
  param([string[]]$Arguments)

  $rendered = foreach ($argument in $Arguments) {
    if ($null -eq $argument -or $argument -eq "") {
      '""'
      continue
    }

    if ($argument -notmatch '[\s"]') {
      $argument
      continue
    }

    $escaped = $argument -replace '(\\*)"', '$1$1\"'
    $escaped = $escaped -replace '(\\+)$', '$1$1'
    '"' + $escaped + '"'
  }

  return ($rendered -join " ").Trim()
}

function Invoke-ExecutableCapture {
  param(
    [string]$FilePath,
    [string[]]$Arguments,
    [int]$TimeoutSeconds = 20
  )

  try {
    $startInfo = New-Object System.Diagnostics.ProcessStartInfo
    $startInfo.FileName = $FilePath
    $startInfo.Arguments = Convert-ToNativeArgumentString -Arguments $Arguments
    $startInfo.UseShellExecute = $false
    $startInfo.CreateNoWindow = $true
    $startInfo.RedirectStandardOutput = $true
    $startInfo.RedirectStandardError = $true

    $process = New-Object System.Diagnostics.Process
    $process.StartInfo = $startInfo
    [void]$process.Start()

    $timedOut = -not $process.WaitForExit($TimeoutSeconds * 1000)
    if ($timedOut) {
      try {
        $process.Kill()
      } catch {
      }
    } else {
      $process.WaitForExit()
    }

    $stdoutRaw = $process.StandardOutput.ReadToEnd()
    $stderrRaw = $process.StandardError.ReadToEnd()

    return [PSCustomObject]@{
      output = Normalize-CapturedText ($stdoutRaw + "`n" + $stderrRaw)
      stdout = Normalize-CapturedText $stdoutRaw
      stderr = Normalize-CapturedText $stderrRaw
      exit_code = if ($timedOut) { -1 } else { $process.ExitCode }
      timed_out = $timedOut
      start_ok = $true
    }
  } catch {
    return [PSCustomObject]@{
      output = Normalize-CapturedText ([string]$_.Exception.Message)
      stdout = ""
      stderr = Normalize-CapturedText ([string]$_.Exception.Message)
      exit_code = $null
      timed_out = $false
      start_ok = $false
    }
  }
}

function Invoke-DockerCliCapture {
  param(
    [string[]]$Arguments,
    [int]$TimeoutSeconds = 20
  )

  return Invoke-ExecutableCapture -FilePath (Get-DockerCliPath) -Arguments $Arguments -TimeoutSeconds $TimeoutSeconds
}

function Invoke-CmdCapture {
  param(
    [string]$Command,
    [int]$TimeoutSeconds
  )

  $tempPath = Join-Path $env:TEMP ("cmd-capture-" + [guid]::NewGuid().ToString("N") + ".log")
  $process = Start-Process -FilePath "cmd.exe" -ArgumentList "/c", "$Command > ""$tempPath"" 2>&1" -PassThru -WindowStyle Hidden
  $timedOut = -not $process.WaitForExit($TimeoutSeconds * 1000)
  if ($timedOut) {
    Stop-Process -Id $process.Id -Force -ErrorAction SilentlyContinue
  }
  $rawOutput = if (Test-Path $tempPath) { Get-Content -Raw $tempPath } else { "" }
  Remove-Item $tempPath -Force -ErrorAction SilentlyContinue
  $output = if ($null -eq $rawOutput) { "" } else { [string]$rawOutput }

  [PSCustomObject]@{
    output = Normalize-CapturedText $output
    exit_code = if ($timedOut) { -1 } else { $process.ExitCode }
    timed_out = $timedOut
  }
}

function Invoke-WslCapture {
  param(
    [string]$Distro,
    [string]$Script,
    [int]$TimeoutSeconds = 20
  )

  $encoded = [Convert]::ToBase64String([System.Text.Encoding]::UTF8.GetBytes($Script))
  $command = "wsl.exe -d $Distro -- sh -lc ""printf '%s' '$encoded' | base64 -d | sh"""
  return Invoke-CmdCapture -Command $command -TimeoutSeconds $TimeoutSeconds
}

function Test-TcpPort {
  param(
    [string]$TargetHost,
    [int]$Port,
    [int]$TimeoutMilliseconds = 3000
  )

  $client = New-Object System.Net.Sockets.TcpClient
  try {
    $result = $client.BeginConnect($TargetHost, $Port, $null, $null)
    $reachable = $result.AsyncWaitHandle.WaitOne($TimeoutMilliseconds, $false)
    if ($reachable) {
      $client.EndConnect($result)
    }
    return [ordered]@{
      host = $TargetHost
      port = $Port
      reachable = $reachable
      timeout_ms = $TimeoutMilliseconds
    }
  } catch {
    return [ordered]@{
      host = $TargetHost
      port = $Port
      reachable = $false
      timeout_ms = $TimeoutMilliseconds
      error = $_.Exception.Message
    }
  } finally {
    $client.Close()
  }
}

function Test-WslTcpPort {
  param(
    [string]$Distro,
    [string]$TargetHost,
    [int]$Port,
    [int]$TimeoutSeconds = 8
  )

  $result = Invoke-WslCapture -Distro $Distro -TimeoutSeconds $TimeoutSeconds -Script @"
if command -v nc >/dev/null 2>&1; then
  nc -vz -w 3 $TargetHost $Port
else
  echo nc-unavailable
  exit 127
fi
"@

  [ordered]@{
    host = $TargetHost
    port = $Port
    reachable = (-not $result.timed_out) -and ($result.exit_code -eq 0)
    exit_code = $result.exit_code
    timed_out = $result.timed_out
    detail = $result.output
  }
}

function Test-WslUdpPort {
  param(
    [string]$Distro,
    [string]$TargetHost,
    [int]$Port,
    [int]$TimeoutSeconds = 8
  )

  $result = Invoke-WslCapture -Distro $Distro -TimeoutSeconds $TimeoutSeconds -Script @"
if command -v nc >/dev/null 2>&1; then
  nc -vzu -w 1 $TargetHost $Port
else
  echo nc-unavailable
  exit 127
fi
"@

  [ordered]@{
    host = $TargetHost
    port = $Port
    attempted = (-not $result.timed_out) -and ($result.exit_code -ne 127)
    exit_code = $result.exit_code
    timed_out = $result.timed_out
    detail = $result.output
  }
}

function Get-DockerDesktopProbeSample {
  param(
    [string]$Distro,
    [string]$ManagerWireGuardAddress,
    [int[]]$TcpPorts,
    [switch]$IncludeOverlayUdpProbe,
    [int]$OverlayUdpPort = 4789
  )

  $routeResult = Invoke-WslCapture -Distro $Distro -TimeoutSeconds 10 -Script @"
ip route get $ManagerWireGuardAddress || true
"@

  $tcpChecks = [ordered]@{}
  foreach ($port in $TcpPorts) {
    $tcpChecks[[string]$port] = Test-WslTcpPort -Distro $Distro -TargetHost $ManagerWireGuardAddress -Port $port
  }

  $overlayUdpProbe = $null
  if ($IncludeOverlayUdpProbe) {
    $overlayUdpProbe = Test-WslUdpPort -Distro $Distro -TargetHost $ManagerWireGuardAddress -Port $OverlayUdpPort
  }

  $allTcpPortsReachable = $true
  foreach ($entry in $tcpChecks.GetEnumerator()) {
    if (-not $entry.Value.reachable) {
      $allTcpPortsReachable = $false
      break
    }
  }

  [ordered]@{
    captured_at = (Get-Date).ToString("o")
    route_get_manager = $routeResult.output
    route_exit_code = $routeResult.exit_code
    route_timed_out = $routeResult.timed_out
    tcp_checks = $tcpChecks
    all_tcp_ports_reachable = $allTcpPortsReachable
    overlay_udp_probe = $overlayUdpProbe
  }
}

function Get-DockerDesktopSoakSummary {
  param(
    [string]$Distro,
    [string]$ManagerWireGuardAddress,
    [int]$SampleCount = 15,
    [int]$IntervalSeconds = 2,
    [switch]$IncludeOverlayUdpProbe,
    [int]$OverlayUdpPort = 4789
  )

  $samples = @()
  for ($index = 0; $index -lt $SampleCount; $index++) {
    $samples += Get-DockerDesktopProbeSample `
      -Distro $Distro `
      -ManagerWireGuardAddress $ManagerWireGuardAddress `
      -TcpPorts @(2377, 7946) `
      -IncludeOverlayUdpProbe:$IncludeOverlayUdpProbe `
      -OverlayUdpPort $OverlayUdpPort
    if ($index -lt ($SampleCount - 1) -and $IntervalSeconds -gt 0) {
      Start-Sleep -Seconds $IntervalSeconds
    }
  }

  $allTcpPortsReachable = $true
  foreach ($sample in $samples) {
    if (-not $sample.all_tcp_ports_reachable) {
      $allTcpPortsReachable = $false
      break
    }
  }

  [ordered]@{
    distro = $Distro
    sample_count = $SampleCount
    interval_seconds = $IntervalSeconds
    include_overlay_udp_probe = [bool]$IncludeOverlayUdpProbe
    overlay_udp_port = if ($IncludeOverlayUdpProbe) { $OverlayUdpPort } else { $null }
    all_tcp_ports_reachable = $allTcpPortsReachable
    samples = $samples
  }
}

function Get-WorkflowOutcomeSummary {
  param($SessionPayload)

  $managerAcceptance = $null
  $minimumTcpValidation = $null
  $managerAcceptanceStatus = $null
  $observedManagerNodeAddr = $null
  $effectiveTargetAddr = $null
  $effectiveTargetSource = $null
  $truthAuthority = $null

  if ($null -ne $SessionPayload) {
    $managerAcceptance = $SessionPayload.manager_acceptance
    $minimumTcpValidation = $SessionPayload.minimum_tcp_validation
    $effectiveTargetAddr = [string]$SessionPayload.effective_target_addr
    $effectiveTargetSource = [string]$SessionPayload.effective_target_source
    $truthAuthority = [string]$SessionPayload.truth_authority
  }

  if ($null -ne $managerAcceptance) {
    $managerAcceptanceStatus = [string]$managerAcceptance.status
    $observedManagerNodeAddr = [string]$managerAcceptance.observed_manager_node_addr
  }

  $rawTargetEstablished = ($managerAcceptanceStatus -eq "matched") -and -not [string]::IsNullOrWhiteSpace($observedManagerNodeAddr)
  $authoritativeTargetEstablished = ($truthAuthority -eq "backend_correction") -and -not [string]::IsNullOrWhiteSpace($effectiveTargetAddr)

  $minimumTcpReachable = $null
  $validatedAgainstManagerTarget = $false
  $validatedAgainstEffectiveTarget = $false
  if ($null -ne $minimumTcpValidation) {
    $minimumTcpReachable = [bool]$minimumTcpValidation.reachable
    $validatedAgainstManagerTarget = [bool]$minimumTcpValidation.validated_against_manager_target
    $validatedAgainstEffectiveTarget = [bool]$minimumTcpValidation.validated_against_effective_target
  }

  $rawTargetReachable = $rawTargetEstablished -and $validatedAgainstManagerTarget -and [bool]$minimumTcpReachable
  $authoritativeTargetReachable = $authoritativeTargetEstablished -and $validatedAgainstEffectiveTarget -and [bool]$minimumTcpReachable

  $workflowTargetEstablished = $false
  $workflowTargetAddr = $null
  $workflowTargetSource = $null
  if ($authoritativeTargetEstablished) {
    $workflowTargetEstablished = $true
    $workflowTargetAddr = $effectiveTargetAddr
    $workflowTargetSource = if ([string]::IsNullOrWhiteSpace($effectiveTargetSource)) {
      "backend_correction"
    } else {
      $effectiveTargetSource
    }
  } elseif ($rawTargetEstablished) {
    $workflowTargetEstablished = $true
    $workflowTargetAddr = $observedManagerNodeAddr
    $workflowTargetSource = "raw_manager"
  }

  $pathOutcome = "incomplete"
  if ($rawTargetReachable) {
    $pathOutcome = "raw_success"
  } elseif ($authoritativeTargetReachable) {
    $pathOutcome = "backend_authoritative_success"
  } elseif ($authoritativeTargetEstablished) {
    $pathOutcome = "backend_authoritative_target_established"
  } elseif ($rawTargetEstablished) {
    $pathOutcome = "raw_target_established"
  }

  return [ordered]@{
    path_outcome = $pathOutcome
    workflow_target_established = $workflowTargetEstablished
    workflow_target_addr = $workflowTargetAddr
    workflow_target_source = $workflowTargetSource
    raw_manager_target_established = [bool]$rawTargetEstablished
    raw_manager_target_reachable = [bool]$rawTargetReachable
    authoritative_target_established = [bool]$authoritativeTargetEstablished
    authoritative_target_reachable = [bool]$authoritativeTargetReachable
    minimum_tcp_reachable = $minimumTcpReachable
  }
}
