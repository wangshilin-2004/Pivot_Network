from __future__ import annotations

import json
from dataclasses import dataclass
from datetime import UTC, datetime
from typing import Any

from seller_client_app.backend import BackendClient, BackendClientError
from seller_client_app.codex_session import CodexSessionError, run_codex_assistant
from seller_client_app.config import Settings
from seller_client_app.errors import LocalAppError
from seller_client_app.local_system import (
    collect_environment_health,
    export_diagnostics_bundle,
    run_overlay_runtime_check,
    run_standard_join_workflow,
)
from seller_client_app.state import SellerClientState


@dataclass(frozen=True, slots=True)
class AssistantIntent:
    prefers_codex: bool
    wants_environment_check: bool
    wants_repair: bool
    wants_overlay_check: bool
    wants_join_workflow: bool
    wants_refresh: bool
    wants_tcp_validation: bool
    wants_export_diagnostics: bool
    wants_state_summary: bool

    @property
    def use_local_workflow(self) -> bool:
        return any(
            [
                self.wants_environment_check,
                self.wants_repair,
                self.wants_overlay_check,
                self.wants_join_workflow,
                self.wants_refresh,
                self.wants_tcp_validation,
                self.wants_export_diagnostics,
                self.wants_state_summary,
            ]
        )


def execute_assistant_request(
    *,
    settings: Settings,
    state: SellerClientState,
    session_id: str,
    user_message: str,
) -> dict[str, Any]:
    intent = classify_assistant_intent(user_message)
    if intent.prefers_codex:
        try:
            result = run_codex_assistant(
                settings=settings,
                state=state,
                session_id=session_id,
                user_message=user_message,
            )
            state.record_assistant_run(result)
            return result
        except CodexSessionError as exc:
            if intent.use_local_workflow:
                result = _run_local_controlled_assistant(
                    settings=settings,
                    state=state,
                    session_id=session_id,
                    user_message=user_message,
                    intent=intent,
                )
                result["assistant_mode"] = "local_controlled_workflow_with_codex_fallback"
                result["codex_error"] = str(exc)
                state.record_assistant_run(result)
                return result
            result = _build_local_state_fallback(
                state=state,
                session_id=session_id,
                user_message=user_message,
                codex_error=str(exc),
            )
            state.record_assistant_run(result)
            return result

    if intent.use_local_workflow:
        result = _run_local_controlled_assistant(
            settings=settings,
            state=state,
            session_id=session_id,
            user_message=user_message,
            intent=intent,
        )
        state.record_assistant_run(result)
        return result

    try:
        return run_codex_assistant(
            settings=settings,
            state=state,
            session_id=session_id,
            user_message=user_message,
        )
    except CodexSessionError as exc:
        result = _build_local_state_fallback(
            state=state,
            session_id=session_id,
            user_message=user_message,
            codex_error=str(exc),
        )
        state.record_assistant_run(result)
        return result


def classify_assistant_intent(user_message: str) -> AssistantIntent:
    lowered = (user_message or "").lower()
    prefers_codex = _contains_any(
        lowered,
        (
            "codex",
            "code x",
            "mcp",
            "不要走本地受控",
            "原生",
            "tool call",
            "tool-calling",
        ),
    )
    wants_join_workflow = _contains_any(
        lowered,
        (
            "join",
            "join workflow",
            "swarm join",
            "加入",
            "接入",
            "入网",
        ),
    )
    wants_repair = _contains_any(
        lowered,
        (
            "repair",
            "fix",
            "install",
            "setup",
            "修复",
            "安装",
            "准备环境",
            "半自动",
        ),
    )
    wants_environment_check = wants_join_workflow or wants_repair or _contains_any(
        lowered,
        (
            "environment",
            "health",
            "doctor",
            "diagnostic",
            "check",
            "检查",
            "环境",
            "健康",
            "诊断",
        ),
    )
    wants_overlay_check = wants_join_workflow or _contains_any(
        lowered,
        (
            "wireguard",
            "docker",
            "swarm",
            "overlay",
            "network",
            "route",
            "wg",
            "网络",
            "路由",
        ),
    )
    wants_refresh = wants_join_workflow or _contains_any(
        lowered,
        (
            "refresh",
            "reload",
            "sync",
            "refresh session",
            "刷新",
            "同步",
            "重新获取状态",
        ),
    )
    wants_tcp_validation = _contains_any(
        lowered,
        (
            "tcp",
            "port",
            "reachable",
            "reachability",
            "connectivity",
            "validation",
            "可达",
            "连通",
            "端口",
            "探测",
            "校验",
        ),
    )
    wants_export_diagnostics = _contains_any(
        lowered,
        (
            "export",
            "diagnostics",
            "diagnostic bundle",
            "logs",
            "导出",
            "诊断包",
            "日志",
        ),
    )
    wants_state_summary = wants_join_workflow or _contains_any(
        lowered,
        (
            "read",
            "state",
            "status",
            "summary",
            "show",
            "读取",
            "状态",
            "总结",
            "汇总",
            "看一下",
        ),
    )
    return AssistantIntent(
        prefers_codex=prefers_codex,
        wants_environment_check=wants_environment_check,
        wants_repair=wants_repair,
        wants_overlay_check=wants_overlay_check,
        wants_join_workflow=wants_join_workflow,
        wants_refresh=wants_refresh,
        wants_tcp_validation=wants_tcp_validation,
        wants_export_diagnostics=wants_export_diagnostics,
        wants_state_summary=wants_state_summary,
    )


def _run_local_controlled_assistant(
    *,
    settings: Settings,
    state: SellerClientState,
    session_id: str,
    user_message: str,
    intent: AssistantIntent,
) -> dict[str, Any]:
    del session_id
    actions_run: list[dict[str, Any]] = []

    if intent.wants_repair or intent.wants_environment_check:
        health_snapshot = collect_environment_health(
            settings,
            expected_wireguard_ip=_expected_wireguard_ip(settings, state),
            repair=intent.wants_repair,
            local_app_port=settings.app_port,
            overlay_sample_count=2,
            overlay_interval_seconds=1,
        )
        state.record_local_health_snapshot(health_snapshot)
        actions_run.append(
            {
                "action": "semi_auto_repair" if intent.wants_repair else "environment_check",
                "ok": True,
                "health_status": ((health_snapshot.get("summary") or {}).get("status")),
                "warnings": list(((health_snapshot.get("summary") or {}).get("warnings")) or []),
                "report_path": health_snapshot.get("report_path"),
            }
        )

    if intent.wants_overlay_check:
        overlay_result = run_overlay_runtime_check(
            settings,
            local_app_port=settings.app_port,
            overlay_sample_count=2,
            overlay_interval_seconds=1,
        )
        state.record_runtime_workflow_result(
            {
                "kind": "overlay_runtime_check",
                "checked_at": _iso_now(),
                "result": overlay_result,
            }
        )
        payload = overlay_result.get("payload") or {}
        windows_overlay = payload.get("windows_overlay") if isinstance(payload, dict) else {}
        actions_run.append(
            {
                "action": "overlay_check",
                "ok": bool(overlay_result.get("ok")),
                "local_app_listening": ((payload.get("local_app") or {}).get("listening")) if isinstance(payload, dict) else None,
                "manager_routes": list((windows_overlay or {}).get("manager_routes") or []),
            }
        )

    if intent.wants_join_workflow:
        onboarding = _require_onboarding_session(state)
        session_file = state.write_session_runtime_file()
        if session_file is None:
            raise LocalAppError(
                step="assistant.join_workflow",
                code="session_file_missing",
                message="The local onboarding session file is not available.",
                hint="Refresh the onboarding session and retry the natural-language join request.",
                status_code=409,
            )
        workflow_result = run_standard_join_workflow(
            settings,
            session_file=str(session_file),
            join_mode="wireguard",
            advertise_address=onboarding.get("expected_wireguard_ip") or settings.default_expected_wireguard_ip,
            data_path_address=onboarding.get("expected_wireguard_ip") or settings.default_expected_wireguard_ip,
            listen_address=None,
            minimum_tcp_validation_port=settings.default_tcp_validation_port,
        )
        refreshed_session = _refresh_onboarding_session(settings, state, onboarding["session_id"])
        state.record_runtime_workflow_result(
            {
                "kind": "standard_join_workflow",
                "ran_at": _iso_now(),
                "workflow": workflow_result,
                "session_id": onboarding["session_id"],
            }
        )
        actions_run.append(
            {
                "action": "join_workflow",
                "ok": bool(workflow_result.get("ok")),
                "session_status": None if refreshed_session is None else refreshed_session.get("status"),
                "effective_target_addr": None if refreshed_session is None else refreshed_session.get("effective_target_addr"),
            }
        )
    elif intent.wants_refresh:
        onboarding = _require_onboarding_session(state)
        refreshed_session = _refresh_onboarding_session(settings, state, onboarding["session_id"])
        actions_run.append(
            {
                "action": "refresh_onboarding_session",
                "ok": refreshed_session is not None,
                "session_status": None if refreshed_session is None else refreshed_session.get("status"),
            }
        )

    if intent.wants_tcp_validation:
        tcp_result = _run_minimum_tcp_validation(settings, state)
        actions_run.append(tcp_result)

    if intent.wants_export_diagnostics:
        bundle = export_diagnostics_bundle(
            settings,
            runtime_snapshot=state.runtime_snapshot(),
            onboarding_session=state.current_onboarding_session(),
        )
        actions_run.append(
            {
                "action": "export_diagnostics",
                "ok": bool(bundle.get("exists")),
                "bundle_path": bundle.get("bundle_path"),
                "size_bytes": bundle.get("size_bytes"),
            }
        )

    snapshot = state.runtime_snapshot()
    return {
        "assistant_mode": "local_controlled_workflow",
        "assistant_message": _build_local_controlled_message(snapshot=snapshot, actions_run=actions_run),
        "user_message": user_message,
        "actions_run": actions_run,
        "session_id": None if snapshot.get("onboarding_session") is None else snapshot["onboarding_session"].get("session_id"),
        "snapshot": snapshot,
    }


def _build_local_state_fallback(
    *,
    state: SellerClientState,
    session_id: str,
    user_message: str,
    codex_error: str,
) -> dict[str, Any]:
    snapshot = state.runtime_snapshot()
    return {
        "assistant_mode": "local_state_fallback",
        "assistant_message": (
            "Codex MCP 在这台 Windows 机器上当前没有正常握手，所以这次先返回本地状态摘要。\n\n"
            + _build_local_controlled_message(snapshot=snapshot, actions_run=[{"action": "read_state", "ok": True}])
        ),
        "user_message": user_message,
        "actions_run": [{"action": "read_state", "ok": True}],
        "session_id": session_id,
        "codex_error": codex_error,
        "snapshot": snapshot,
    }


def _expected_wireguard_ip(settings: Settings, state: SellerClientState) -> str | None:
    onboarding = state.current_onboarding_session()
    if onboarding is None:
        return settings.default_expected_wireguard_ip
    return onboarding.get("expected_wireguard_ip") or settings.default_expected_wireguard_ip


def _require_onboarding_session(state: SellerClientState) -> dict[str, Any]:
    onboarding = state.current_onboarding_session()
    if onboarding is None:
        raise LocalAppError(
            step="assistant",
            code="onboarding_session_missing",
            message="Onboarding session is not initialized.",
            hint="Create or attach an onboarding session before asking the assistant to run join actions.",
            status_code=409,
        )
    return onboarding


def _require_backend_client(settings: Settings, state: SellerClientState) -> BackendClient:
    token = state.auth_token()
    if token is None:
        raise LocalAppError(
            step="assistant",
            code="auth_required",
            message="Seller login is required before the assistant can call backend onboarding actions.",
            hint="Log in from the local seller client first.",
            status_code=401,
        )
    return BackendClient(settings, token=token)


def _refresh_onboarding_session(settings: Settings, state: SellerClientState, session_id: str) -> dict[str, Any] | None:
    client = _require_backend_client(settings, state)
    try:
        updated = client.get_onboarding_session(session_id)
    except BackendClientError as exc:
        raise LocalAppError(
            step="assistant.refresh_onboarding",
            code="backend_request_failed",
            message="Failed to refresh the onboarding session from the backend.",
            hint="Check backend connectivity and retry the assistant request.",
            details=exc.payload or {"detail": exc.detail},
            status_code=exc.status_code if 400 <= exc.status_code < 600 else 502,
        ) from exc
    state.update_onboarding_session(updated)
    return updated


def _run_minimum_tcp_validation(settings: Settings, state: SellerClientState) -> dict[str, Any]:
    onboarding = _require_onboarding_session(state)
    target_addr = (
        onboarding.get("effective_target_addr")
        or (onboarding.get("manager_acceptance") or {}).get("expected_wireguard_ip")
        or onboarding.get("expected_wireguard_ip")
        or settings.default_expected_wireguard_ip
        or settings.manager_wireguard_address
    )
    tcp_record = state.record_tcp_validation(
        {
            "host": target_addr,
            "port": settings.default_tcp_validation_port,
            "source": "assistant_local_controlled_workflow",
            "target_label": "effective_target_or_expected_wireguard_ip",
            "notes": ["triggered from local natural-language assistant"],
        }
    )
    validation = tcp_record.get("validation") or {}
    try:
        updated = _require_backend_client(settings, state).submit_minimum_tcp_validation(
            onboarding["session_id"],
            {
                "reported_phase": "repair",
                "target_addr": target_addr,
                "target_port": settings.default_tcp_validation_port,
                "protocol": "tcp",
                "reachable": bool(validation.get("reachable")),
                "notes": ["submitted from local natural-language assistant"],
            },
        )
        state.update_onboarding_session(updated)
        backend_status = "submitted"
    except LocalAppError:
        raise
    except BackendClientError as exc:
        backend_status = f"submit_failed: {exc.detail}"

    return {
        "action": "minimum_tcp_validation",
        "ok": True,
        "host": validation.get("host"),
        "port": validation.get("port"),
        "reachable": validation.get("reachable"),
        "backend_status": backend_status,
    }


def _build_local_controlled_message(*, snapshot: dict[str, Any], actions_run: list[dict[str, Any]]) -> str:
    onboarding = snapshot.get("onboarding_session") or {}
    health_snapshot = snapshot.get("local_health_snapshot") or {}
    health_summary = health_snapshot.get("summary") or {}
    health_status = health_summary.get("status") or "unknown"
    health_warnings = list(health_summary.get("warnings") or [])
    manager_acceptance = onboarding.get("manager_acceptance") or {}
    tcp_validation = onboarding.get("minimum_tcp_validation") or (snapshot.get("runtime_evidence") or {}).get("latest_tcp_validation") or {}
    action_names = [str(item.get("action")) for item in actions_run if item.get("action")]
    local_join = _describe_local_join(snapshot)
    manager_raw_truth = _describe_manager_raw_truth(manager_acceptance)
    authoritative_target = _describe_authoritative_target(onboarding)
    tcp_summary = _describe_tcp_validation(tcp_validation)

    lines = [
        "本次请求已走本地受控工作流。",
        f"已执行动作: {', '.join(action_names) if action_names else 'read_state'}",
        f"Session: {onboarding.get('session_id') or '未初始化'}",
        f"后端状态: {onboarding.get('status') or 'unknown'}",
        f"本地环境: {health_status}" + (f" (warnings: {', '.join(health_warnings)})" if health_warnings else ""),
        f"本地 join: {local_join}",
        f"manager raw truth: {manager_raw_truth}",
        f"backend authoritative target: {authoritative_target}",
        f"TCP validation: {tcp_summary}",
    ]
    return "\n".join(lines)


def _describe_local_join(snapshot: dict[str, Any]) -> str:
    health_snapshot = snapshot.get("local_health_snapshot") or {}
    docker = health_snapshot.get("docker") or {}
    node_state = docker.get("local_node_state")
    node_addr = docker.get("node_addr")

    workflow = snapshot.get("last_runtime_workflow") or {}
    workflow_payload = workflow.get("workflow") if workflow.get("kind") == "standard_join_workflow" else {}
    join_payload = (workflow_payload or {}).get("payload") or {}
    join_result = join_payload.get("join_result") if isinstance(join_payload, dict) else {}
    after_state = _parse_json_dict((join_result or {}).get("after_state"))
    node_state = after_state.get("LocalNodeState") or node_state
    node_addr = after_state.get("NodeAddr") or node_addr

    onboarding = snapshot.get("onboarding_session") or {}
    if node_state or node_addr:
        details = ", ".join(
            item
            for item in [
                None if node_state is None else f"LocalNodeState={node_state}",
                None if node_addr is None else f"NodeAddr={node_addr}",
            ]
            if item
        )
        return details
    if onboarding.get("last_join_complete"):
        return "join_complete 已提交，但本地 Docker 状态摘要缺失"
    return "未确认"


def _describe_manager_raw_truth(manager_acceptance: dict[str, Any]) -> str:
    if not manager_acceptance:
        return "未返回"
    details = [
        f"status={manager_acceptance.get('status') or 'unknown'}",
        f"matched={manager_acceptance.get('matched')}",
        f"observed_addr={manager_acceptance.get('observed_manager_node_addr') or 'unknown'}",
        f"detail={manager_acceptance.get('detail') or 'unknown'}",
    ]
    return ", ".join(details)


def _describe_authoritative_target(onboarding: dict[str, Any]) -> str:
    target = onboarding.get("effective_target_addr")
    source = onboarding.get("effective_target_source") or onboarding.get("truth_authority")
    if target:
        return f"{target} (source={source or 'unknown'})"
    return f"未建立 (truth_authority={source or 'unknown'})"


def _describe_tcp_validation(tcp_validation: dict[str, Any]) -> str:
    if not tcp_validation:
        return "未记录"
    host = tcp_validation.get("target_addr") or tcp_validation.get("host") or "unknown"
    port = tcp_validation.get("target_port") or tcp_validation.get("port") or "unknown"
    reachable = tcp_validation.get("reachable")
    return f"reachable={reachable}, target={host}:{port}"


def _parse_json_dict(raw: Any) -> dict[str, Any]:
    if isinstance(raw, dict):
        return raw
    if not raw:
        return {}
    try:
        payload = json.loads(str(raw))
    except ValueError:
        return {}
    return payload if isinstance(payload, dict) else {}


def _contains_any(text: str, candidates: tuple[str, ...]) -> bool:
    return any(candidate in text for candidate in candidates)


def _iso_now() -> str:
    return datetime.now(UTC).isoformat()
