from __future__ import annotations

import argparse
import json
import os
import platform
import shutil
import socket
import subprocess
import sys
from datetime import UTC, datetime
from pathlib import Path
from typing import Any
from zipfile import ZIP_DEFLATED, ZipFile

import httpx

from seller_client_app.config import Settings, get_settings


def collect_environment_health(
    settings: Settings,
    *,
    expected_wireguard_ip: str | None = None,
    repair: bool = False,
    local_app_port: int | None = None,
    overlay_sample_count: int = 3,
    overlay_interval_seconds: int = 1,
) -> dict[str, Any]:
    report_path = settings.health_root_path / "latest-health-report.json"
    repair_actions: list[str] = []
    if repair:
        repair_actions = _apply_local_repairs(settings)

    overlay_runtime = run_overlay_runtime_check(
        settings,
        local_app_port=local_app_port,
        overlay_sample_count=overlay_sample_count,
        overlay_interval_seconds=overlay_interval_seconds,
    )
    overlay_payload = overlay_runtime.get("payload") if overlay_runtime.get("ok") else None

    report = {
        "captured_at": _timestamp(),
        "repair_requested": repair,
        "repair_actions": repair_actions,
        "report_path": str(report_path),
        "system": _collect_system_section(),
        "python_runtime": _collect_python_runtime_section(settings),
        "codex": _collect_codex_section(settings),
        "wsl": _collect_wsl_section(settings),
        "wireguard": _collect_wireguard_section(settings, overlay_payload, expected_wireguard_ip),
        "docker": _collect_docker_section(settings, overlay_payload),
        "backend_connectivity": _collect_backend_connectivity_section(settings),
        "seller_client_runtime": _collect_seller_client_runtime_section(
            settings,
            overlay_payload,
            report_path=report_path,
            local_app_port=local_app_port,
        ),
    }
    report["summary"] = _build_health_summary(report)
    report_path.parent.mkdir(parents=True, exist_ok=True)
    report_path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    return report


def run_overlay_runtime_check(
    settings: Settings,
    *,
    local_app_port: int | None = None,
    overlay_sample_count: int = 3,
    overlay_interval_seconds: int = 1,
) -> dict[str, Any]:
    script_path = settings.project_root / "bootstrap" / "windows" / "check_windows_overlay_runtime.ps1"
    if not script_path.exists():
        return {
            "ok": False,
            "step": "overlay_runtime_check",
            "error": f"script_not_found: {script_path}",
            "payload": None,
        }
    if platform.system() != "Windows":
        return {
            "ok": False,
            "step": "overlay_runtime_check",
            "error": "windows_only",
            "payload": None,
        }

    completed = _run_process(
        [
            "powershell.exe",
            "-NoProfile",
            "-ExecutionPolicy",
            "Bypass",
            "-File",
            str(script_path),
            "-HostTunnelName",
            settings.windows_wireguard_tunnel_name,
            "-LocalAppPort",
            str(local_app_port or settings.app_port),
            "-ManagerWireGuardAddress",
            settings.manager_wireguard_address,
            "-ManagerPublicAddress",
            settings.manager_public_address,
            "-ManagerSshPort",
            str(settings.manager_ssh_port),
            "-UbuntuDistro",
            settings.windows_ubuntu_distro,
            "-DockerDesktopSoakSampleCount",
            str(max(1, overlay_sample_count)),
            "-DockerDesktopSoakIntervalSeconds",
            str(max(0, overlay_interval_seconds)),
        ],
        timeout_seconds=max(20, overlay_sample_count * max(1, overlay_interval_seconds) + 20),
    )
    payload = _parse_json_blob(completed["stdout"]) or _parse_json_blob(completed["combined"])
    return {
        "ok": completed["ok"] and isinstance(payload, dict),
        "step": "overlay_runtime_check",
        "error": None if completed["ok"] else completed["combined"],
        "command": completed["command"],
        "exit_code": completed["exit_code"],
        "stdout": completed["stdout"],
        "stderr": completed["stderr"],
        "payload": payload if isinstance(payload, dict) else None,
    }


def run_standard_join_workflow(
    settings: Settings,
    *,
    session_file: str,
    join_mode: str = "wireguard",
    advertise_address: str | None = None,
    data_path_address: str | None = None,
    listen_address: str | None = None,
    minimum_tcp_validation_port: int | None = None,
    post_join_probe_count: int | None = None,
    probe_interval_seconds: int | None = None,
    manager_probe_count: int | None = None,
    manager_probe_interval_seconds: int | None = None,
) -> dict[str, Any]:
    script_path = settings.project_root / "bootstrap" / "windows" / "attempt_manager_addr_correction_cycle.ps1"
    if not script_path.exists():
        return {
            "ok": False,
            "step": "standard_join_workflow",
            "error": f"script_not_found: {script_path}",
            "payload": None,
        }
    if platform.system() != "Windows":
        return {
            "ok": False,
            "step": "standard_join_workflow",
            "error": "windows_only",
            "payload": None,
        }

    expected_ip = advertise_address or settings.default_expected_wireguard_ip or settings.manager_wireguard_address
    listen = listen_address or f"{expected_ip}:2377"
    command = [
        "powershell.exe",
        "-NoProfile",
        "-ExecutionPolicy",
        "Bypass",
        "-File",
        str(script_path),
        "-SessionFilePath",
        session_file,
        "-JoinMode",
        join_mode,
        "-ManagerWireGuardAddress",
        settings.manager_wireguard_address,
        "-AdvertiseAddress",
        expected_ip,
        "-DataPathAddress",
        data_path_address or expected_ip,
        "-ListenAddress",
        listen,
        "-ManagerHostName",
        settings.manager_public_address,
        "-ManagerSshPort",
        str(settings.manager_ssh_port),
        "-ManagerMonitorUbuntuDistro",
        settings.windows_ubuntu_distro,
        "-MinimumTcpValidationPort",
        str(minimum_tcp_validation_port or settings.default_tcp_validation_port),
    ]
    if post_join_probe_count is not None:
        command += ["-PostJoinProbeCount", str(max(0, post_join_probe_count))]
    if probe_interval_seconds is not None:
        command += ["-ProbeIntervalSeconds", str(max(0, probe_interval_seconds))]
    if manager_probe_count is not None:
        command += ["-ManagerProbeCount", str(max(0, manager_probe_count))]
    if manager_probe_interval_seconds is not None:
        command += ["-ManagerProbeIntervalSeconds", str(max(0, manager_probe_interval_seconds))]

    completed = _run_process(
        command,
        timeout_seconds=900,
    )
    payload = _parse_json_blob(completed["stdout"]) or _parse_json_blob(completed["combined"])
    return {
        "ok": completed["ok"],
        "step": "standard_join_workflow",
        "command": completed["command"],
        "exit_code": completed["exit_code"],
        "stdout": completed["stdout"],
        "stderr": completed["stderr"],
        "payload": payload if isinstance(payload, dict) else None,
    }


def clear_join_state(
    settings: Settings,
    *,
    leave_timeout_seconds: int = 25,
    dry_run: bool = False,
) -> dict[str, Any]:
    script_path = settings.project_root / "bootstrap" / "windows" / "clear_windows_join_state.ps1"
    if not script_path.exists():
        return {
            "ok": False,
            "step": "clear_join_state",
            "error": f"script_not_found: {script_path}",
            "payload": None,
        }
    if platform.system() != "Windows":
        return {
            "ok": False,
            "step": "clear_join_state",
            "error": "windows_only",
            "payload": None,
        }

    command = [
        "powershell.exe",
        "-NoProfile",
        "-ExecutionPolicy",
        "Bypass",
        "-File",
        str(script_path),
        "-LeaveTimeoutSeconds",
        str(max(1, leave_timeout_seconds)),
    ]
    if dry_run:
        command.append("-DryRun")

    completed = _run_process(command, timeout_seconds=max(30, leave_timeout_seconds + 15))
    payload = _parse_json_blob(completed["stdout"]) or _parse_json_blob(completed["combined"])
    return {
        "ok": completed["ok"] and isinstance(payload, dict) and bool(payload.get("ok", True)),
        "step": "clear_join_state",
        "error": None if completed["ok"] else completed["combined"],
        "command": completed["command"],
        "exit_code": completed["exit_code"],
        "stdout": completed["stdout"],
        "stderr": completed["stderr"],
        "payload": payload if isinstance(payload, dict) else None,
    }


def export_diagnostics_bundle(
    settings: Settings,
    *,
    runtime_snapshot: dict[str, Any],
    onboarding_session: dict[str, Any] | None,
) -> dict[str, Any]:
    settings.exports_root_path.mkdir(parents=True, exist_ok=True)
    bundle_path = settings.exports_root_path / f"seller-client-diagnostics-{datetime.now(UTC):%Y%m%d%H%M%S}.zip"
    with ZipFile(bundle_path, "w", compression=ZIP_DEFLATED) as archive:
        archive.writestr(
            "runtime_snapshot.json",
            json.dumps(runtime_snapshot, ensure_ascii=False, indent=2),
        )
        health_path = settings.health_root_path / "latest-health-report.json"
        if health_path.exists():
            archive.write(health_path, arcname="health/latest-health-report.json")

        if onboarding_session is not None:
            session_id = onboarding_session.get("session_id")
            if session_id:
                session_root = settings.workspace_root_path / settings.session_subdir_name / str(session_id)
                if session_root.exists():
                    for file_path in session_root.rglob("*"):
                        if file_path.is_file():
                            archive.write(file_path, arcname=str(Path("session") / file_path.relative_to(session_root)))

    return {
        "bundle_path": str(bundle_path),
        "created_at": _timestamp(),
        "exists": bundle_path.exists(),
        "size_bytes": bundle_path.stat().st_size if bundle_path.exists() else 0,
    }


def _apply_local_repairs(settings: Settings) -> list[str]:
    actions: list[str] = []
    for path in (
        settings.workspace_root_path,
        settings.workspace_root_path / settings.session_subdir_name,
        settings.health_root_path,
        settings.exports_root_path,
    ):
        path.mkdir(parents=True, exist_ok=True)
        actions.append(f"ensured_path:{path}")

    venv_dir = settings.project_root / ".venv"
    venv_python = _venv_python_path(venv_dir)
    bootstrap_python = _resolve_bootstrap_python()
    if not venv_python.exists():
        completed = _run_process([str(bootstrap_python), "-m", "venv", str(venv_dir)], timeout_seconds=240)
        if completed["ok"]:
            actions.append(f"created_venv:{venv_dir}")
        else:
            actions.append(f"venv_create_failed:{completed['combined']}")

    if venv_python.exists():
        pip_upgrade = _run_process([str(venv_python), "-m", "pip", "install", "--upgrade", "pip"], timeout_seconds=240)
        actions.append("pip_upgraded" if pip_upgrade["ok"] else f"pip_upgrade_failed:{pip_upgrade['combined']}")
        install = _run_process([str(venv_python), "-m", "pip", "install", "-e", str(settings.project_root)], timeout_seconds=300)
        actions.append("seller_client_installed" if install["ok"] else f"editable_install_failed:{install['combined']}")

    return actions


def _collect_system_section() -> dict[str, Any]:
    return {
        "status": "ok" if platform.system() == "Windows" else "warning",
        "platform": platform.system(),
        "release": platform.release(),
        "version": platform.version(),
        "machine": platform.machine(),
        "python_pid": os.getpid(),
    }


def _collect_python_runtime_section(settings: Settings) -> dict[str, Any]:
    venv_dir = settings.project_root / ".venv"
    venv_python = _venv_python_path(venv_dir)
    return {
        "status": "ok" if venv_python.exists() else "warning",
        "current_executable": sys.executable,
        "current_version": sys.version.split()[0],
        "project_root": str(settings.project_root),
        "venv_dir": str(venv_dir),
        "venv_exists": venv_dir.exists(),
        "venv_python": str(venv_python),
        "venv_python_exists": venv_python.exists(),
        "package_metadata_exists": (settings.project_root / "seller_client.egg-info").exists(),
    }


def _collect_codex_section(settings: Settings) -> dict[str, Any]:
    codex_path = shutil.which(settings.codex_command)
    auth_path = settings.codex_auth_source_path
    config_template = settings.codex_config_template_path
    version_result = None
    if codex_path:
        version_result = _run_process([codex_path, "--version"], timeout_seconds=20)

    return {
        "status": "ok" if codex_path and auth_path.exists() and config_template.exists() else "warning",
        "command": settings.codex_command,
        "cli_path": codex_path,
        "cli_available": codex_path is not None,
        "cli_version": None if version_result is None else version_result["stdout"],
        "auth_source_path": str(auth_path),
        "auth_exists": auth_path.exists(),
        "config_template_path": str(config_template),
        "config_template_exists": config_template.exists(),
    }


def _collect_wsl_section(settings: Settings) -> dict[str, Any]:
    wsl_path = shutil.which("wsl.exe")
    if not wsl_path:
        return {
            "status": "warning",
            "wsl_available": False,
            "ubuntu_distro": settings.windows_ubuntu_distro,
            "ubuntu_present": False,
            "distros": "",
        }

    completed = _run_process([wsl_path, "-l", "-v"], timeout_seconds=20)
    stdout = completed["stdout"]
    return {
        "status": "ok" if completed["ok"] and settings.windows_ubuntu_distro.lower() in stdout.lower() else "warning",
        "wsl_available": True,
        "wsl_command": wsl_path,
        "ubuntu_distro": settings.windows_ubuntu_distro,
        "ubuntu_present": settings.windows_ubuntu_distro.lower() in stdout.lower(),
        "distros": stdout,
    }


def _collect_wireguard_section(
    settings: Settings,
    overlay_payload: dict[str, Any] | None,
    expected_wireguard_ip: str | None,
) -> dict[str, Any]:
    service = (overlay_payload or {}).get("wireguard_service") or {}
    windows_overlay = (overlay_payload or {}).get("windows_overlay") or {}
    overlay_addresses = list(windows_overlay.get("overlay_addresses") or [])
    manager_port_checks = list(windows_overlay.get("manager_port_checks") or [])
    expected_ip = expected_wireguard_ip or settings.default_expected_wireguard_ip
    expected_ip_present = bool(
        expected_ip
        and any(str(item.get("IPAddress") or "") == expected_ip for item in overlay_addresses if isinstance(item, dict))
    )
    ports_reachable = all(bool(item.get("reachable")) for item in manager_port_checks) if manager_port_checks else False
    service_running = str(service.get("status") or "").lower() == "running"
    wg_show = str((overlay_payload or {}).get("windows_wireguard") or "").strip()

    return {
        "status": "ok" if service_running and expected_ip_present and ports_reachable else "warning",
        "interface_name": settings.windows_wireguard_tunnel_name,
        "service_running": service_running,
        "service": service,
        "expected_wireguard_ip": expected_ip,
        "expected_wireguard_ip_present": expected_ip_present,
        "manager_wireguard_address": settings.manager_wireguard_address,
        "manager_port_checks": manager_port_checks,
        "route_summary": list(windows_overlay.get("manager_routes") or []),
        "overlay_addresses": overlay_addresses,
        "wg_show": wg_show,
    }


def _collect_docker_section(settings: Settings, overlay_payload: dict[str, Any] | None) -> dict[str, Any]:
    docker_service = (overlay_payload or {}).get("docker_service") or {}
    docker_swarm = (overlay_payload or {}).get("docker_swarm") or {}
    docker_contexts = (overlay_payload or {}).get("docker_contexts") or {}
    swarm_payload = _parse_json_blob(str(docker_swarm.get("stdout") or ""))
    local_node_state = None if not isinstance(swarm_payload, dict) else swarm_payload.get("LocalNodeState")
    node_addr = None if not isinstance(swarm_payload, dict) else swarm_payload.get("NodeAddr")

    return {
        "status": "ok" if docker_swarm.get("exit_code") == 0 else "warning",
        "docker_service": docker_service,
        "docker_cli_available": docker_swarm.get("start_ok", docker_swarm.get("exit_code") == 0),
        "docker_info_available": docker_swarm.get("exit_code") == 0,
        "docker_contexts": docker_contexts,
        "swarm": swarm_payload if isinstance(swarm_payload, dict) else {},
        "local_node_state": local_node_state,
        "node_addr": node_addr,
        "manager_public_address": settings.manager_public_address,
        "docker_desktop": (overlay_payload or {}).get("docker_desktop") or {},
    }


def _collect_backend_connectivity_section(settings: Settings) -> dict[str, Any]:
    url = f"{settings.backend_base_url}{settings.backend_api_prefix}/health"
    try:
        with httpx.Client(timeout=10.0, trust_env=False) as client:
            response = client.get(url)
        payload = response.json() if response.content else {}
        return {
            "status": "ok" if response.is_success else "warning",
            "url": url,
            "reachable": response.is_success,
            "status_code": response.status_code,
            "payload": payload,
        }
    except Exception as exc:
        return {
            "status": "warning",
            "url": url,
            "reachable": False,
            "status_code": None,
            "payload": {},
            "error": str(exc),
        }


def _collect_seller_client_runtime_section(
    settings: Settings,
    overlay_payload: dict[str, Any] | None,
    *,
    report_path: Path,
    local_app_port: int | None,
) -> dict[str, Any]:
    session_root = settings.workspace_root_path / settings.session_subdir_name
    session_count = len([path for path in session_root.iterdir() if path.is_dir()]) if session_root.exists() else 0
    app_listener = (((overlay_payload or {}).get("local_app") or {}).get("listening"))
    root_status = (((overlay_payload or {}).get("local_app") or {}).get("root")) or {}
    return {
        "status": "ok",
        "workspace_root": str(settings.workspace_root_path),
        "session_root": str(session_root),
        "session_count": session_count,
        "health_report_path": str(report_path),
        "exports_root": str(settings.exports_root_path),
        "local_app_port": local_app_port or settings.app_port,
        "local_app_listening": bool(app_listener) if app_listener is not None else _is_tcp_listener_open(local_app_port or settings.app_port),
        "local_app_root": root_status,
    }


def _build_health_summary(report: dict[str, Any]) -> dict[str, Any]:
    sections = [
        "system",
        "python_runtime",
        "codex",
        "wsl",
        "wireguard",
        "docker",
        "backend_connectivity",
        "seller_client_runtime",
    ]
    warnings = [name for name in sections if str(report.get(name, {}).get("status")) != "ok"]
    return {
        "status": "healthy" if not warnings else "needs_attention",
        "sections_checked": sections,
        "warnings": warnings,
    }


def _is_tcp_listener_open(port: int) -> bool:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.settimeout(0.5)
        return sock.connect_ex(("127.0.0.1", port)) == 0


def _run_process(command: list[str], *, timeout_seconds: int) -> dict[str, Any]:
    try:
        completed = subprocess.run(
            command,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=timeout_seconds,
            check=False,
        )
    except (OSError, subprocess.SubprocessError) as exc:
        return {
            "ok": False,
            "command": command,
            "exit_code": None,
            "stdout": "",
            "stderr": str(exc),
            "combined": str(exc),
        }
    stdout = (completed.stdout or "").strip()
    stderr = (completed.stderr or "").strip()
    combined = "\n".join(part for part in [stdout, stderr] if part).strip()
    return {
        "ok": completed.returncode == 0,
        "command": command,
        "exit_code": completed.returncode,
        "stdout": stdout,
        "stderr": stderr,
        "combined": combined,
    }


def _parse_json_blob(text: str) -> dict[str, Any] | list[Any] | None:
    cleaned = (text or "").replace("\x00", "").strip()
    if not cleaned:
        return None
    for start_char, end_char in (("{", "}"), ("[", "]")):
        start = cleaned.find(start_char)
        end = cleaned.rfind(end_char)
        if start >= 0 and end > start:
            candidate = cleaned[start : end + 1]
            try:
                return json.loads(candidate)
            except ValueError:
                continue
    try:
        return json.loads(cleaned)
    except ValueError:
        return None


def _resolve_bootstrap_python() -> Path:
    candidates = [Path(sys.executable)]
    for command in ("python", "py"):
        resolved = shutil.which(command)
        if resolved:
            candidates.append(Path(resolved))
    for candidate in candidates:
        if candidate.exists():
            return candidate
    raise RuntimeError("Unable to locate a Python interpreter for seller client bootstrap.")


def _venv_python_path(venv_dir: Path) -> Path:
    if platform.system() == "Windows":
        return venv_dir / "Scripts" / "python.exe"
    return venv_dir / "bin" / "python"


def _timestamp() -> str:
    return datetime.now(UTC).isoformat()


def main() -> None:
    parser = argparse.ArgumentParser(description="Collect or repair the local seller client environment health report.")
    parser.add_argument("--repair", action="store_true")
    parser.add_argument("--expected-wireguard-ip", default=None)
    parser.add_argument("--overlay-sample-count", type=int, default=3)
    parser.add_argument("--overlay-interval-seconds", type=int, default=1)
    args = parser.parse_args()

    payload = collect_environment_health(
        get_settings(),
        expected_wireguard_ip=args.expected_wireguard_ip,
        repair=args.repair,
        overlay_sample_count=args.overlay_sample_count,
        overlay_interval_seconds=args.overlay_interval_seconds,
    )
    print(json.dumps(payload, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
