let windowSessionId = null;
let windowHeartbeatTimer = null;
let currentSnapshot = null;

const onboardingSessionStorageKey = "pivot-seller-current-session-id";

function getStoredOnboardingSessionId() {
  return window.localStorage.getItem(onboardingSessionStorageKey);
}

function setStoredOnboardingSessionId(sessionId) {
  if (!sessionId) {
    return;
  }
  window.localStorage.setItem(onboardingSessionStorageKey, sessionId);
  renderStoredSessionStatus(sessionId);
}

function clearStoredOnboardingSessionId() {
  window.localStorage.removeItem(onboardingSessionStorageKey);
  renderStoredSessionStatus(null);
}

function writeOutput(id, payload) {
  const target = document.getElementById(id);
  if (!target) {
    return;
  }
  target.textContent = JSON.stringify(payload, null, 2);
}

function renderWindowSessionStatus(payload) {
  const target = document.getElementById("window-session-status");
  if (!target) {
    return;
  }
  if (!payload || !payload.session_id) {
    target.textContent = "窗口 session 未初始化";
    return;
  }
  target.textContent = `窗口 session: ${payload.session_id} / TTL ${payload.ttl_seconds}s`;
}

function renderStoredSessionStatus(sessionId) {
  const target = document.getElementById("stored-session-status");
  if (!target) {
    return;
  }
  target.textContent = sessionId
    ? `本地保存的 onboarding session_id: ${sessionId}`
    : "本地未保存 onboarding session_id";
}

async function api(path, options = {}) {
  const headers = { ...(options.headers || {}) };
  if (!headers["Content-Type"] && options.body !== undefined) {
    headers["Content-Type"] = "application/json";
  }
  if (windowSessionId) {
    headers["X-Window-Session-Id"] = windowSessionId;
  }
  const response = await fetch(path, { ...options, headers });
  const payload = await response.json().catch(() => ({}));
  if (!response.ok) {
    const error = new Error(payload?.error?.message || payload?.detail || "Request failed");
    error.payload = payload;
    error.status = response.status;
    throw error;
  }
  return payload;
}

function clearFeedback(id) {
  const box = document.getElementById(id);
  if (!box) {
    return;
  }
  box.className = "feedback hidden";
  box.innerHTML = "";
}

function renderFeedback(id, payload, kind = "error") {
  const box = document.getElementById(id);
  if (!box) {
    return;
  }
  const error = payload?.error || payload;
  const step = error.step ? `<p><strong>步骤</strong> ${error.step}</p>` : "";
  const code = error.code ? `<p><strong>代码</strong> ${error.code}</p>` : "";
  const hint = error.hint ? `<p><strong>建议</strong> ${error.hint}</p>` : "";
  box.className = `feedback ${kind}`;
  box.innerHTML = `<h3>${error.message || "请求失败"}</h3>${step}${code}${hint}`;
}

function handleError(outputId, feedbackId, error) {
  const payload = error.payload || { error: { message: String(error) } };
  renderFeedback(feedbackId, payload);
  writeOutput(outputId, payload);
}

function parseJsonEditor(id) {
  const raw = document.getElementById(id).value.trim();
  if (!raw) {
    return {};
  }
  return JSON.parse(raw);
}

function renderDraftEditors(drafts) {
  const payloads = drafts?.write_payloads || {};
  document.getElementById("host-probe-editor").value = JSON.stringify(payloads.linux_host_probe || {}, null, 2);
  document.getElementById("substrate-probe-editor").value = JSON.stringify(payloads.linux_substrate_probe || {}, null, 2);
  document.getElementById("runtime-probe-editor").value = JSON.stringify(payloads.container_runtime_probe || {}, null, 2);
  document.getElementById("join-complete-editor").value = JSON.stringify(payloads.join_complete || {}, null, 2);
}

function renderSummary(snapshot) {
  const onboarding = snapshot?.onboarding_session || {};
  const health = snapshot?.local_health_snapshot || {};
  const docker = health?.docker || {};
  const summary = health?.summary || {};
  const managerAcceptance = onboarding?.manager_acceptance || {};
  const minimumTcpValidation = onboarding?.minimum_tcp_validation || {};
  const targetAddr = onboarding?.effective_target_addr || managerAcceptance?.observed_manager_node_addr || "未建立";
  const truthAuthority = onboarding?.truth_authority || "unknown";

  document.getElementById("env-status-pill").textContent = `环境状态: ${summary.status || "未检查"}`;
  document.getElementById("onboarding-status-pill").textContent = `接入状态: ${onboarding?.status || "未开始"}`;
  document.getElementById("truth-status-pill").textContent = `目标判定: ${truthAuthority}`;

  document.getElementById("summary-env").textContent = summary.status || "未检查";
  document.getElementById("summary-env-detail").textContent = summary.warnings?.length
    ? `待关注: ${summary.warnings.join(", ")}`
    : "环境检查通过后，这里会显示风险摘要。";

  document.getElementById("summary-swarm").textContent = docker?.local_node_state || "未知";
  document.getElementById("summary-swarm-detail").textContent = docker?.node_addr
    ? `NodeAddr: ${docker.node_addr}`
    : "等待 Docker / Swarm 检查。";

  document.getElementById("summary-manager").textContent = managerAcceptance?.status || "未知";
  document.getElementById("summary-manager-detail").textContent = managerAcceptance?.observed_manager_node_addr
    ? `Manager 记录地址: ${managerAcceptance.observed_manager_node_addr}`
    : "等待 manager raw truth。";

  document.getElementById("summary-target").textContent = targetAddr;
  document.getElementById("summary-target-detail").textContent = minimumTcpValidation?.target_addr
    ? `TCP ${minimumTcpValidation.reachable ? "reachable" : "unreachable"} / ${minimumTcpValidation.target_addr}:${minimumTcpValidation.target_port}`
    : `truth_authority: ${truthAuthority}`;
}

function renderSectionOutputs(snapshot) {
  const onboarding = snapshot?.onboarding_session || null;
  const health = snapshot?.local_health_snapshot || {};
  const workflow = snapshot?.last_runtime_workflow || null;
  writeOutput("health-output", health || {});
  writeOutput(
    "network-output",
    workflow?.kind === "overlay_runtime_check" ? workflow : {
      wireguard: health?.wireguard || {},
      runtime_workflow: workflow,
      runtime_evidence: snapshot?.runtime_evidence || {},
    },
  );
  writeOutput(
    "docker-output",
    workflow?.kind === "standard_join_workflow" ? workflow : {
      docker: health?.docker || {},
      onboarding_session: onboarding,
      runtime_workflow: workflow,
    },
  );
  writeOutput("session-output", {
    current_user: snapshot?.current_user,
    auth_session: snapshot?.auth_session,
    onboarding_session: onboarding,
    paths: snapshot?.paths,
  });
  writeOutput("join-material-output", onboarding ? {
    session_id: onboarding.session_id,
    expected_wireguard_ip: onboarding.expected_wireguard_ip,
    swarm_join_material: onboarding.swarm_join_material || {},
    required_labels: onboarding.required_labels || {},
    manager_acceptance: onboarding.manager_acceptance || {},
    effective_target_addr: onboarding.effective_target_addr,
    effective_target_source: onboarding.effective_target_source,
    truth_authority: onboarding.truth_authority,
    minimum_tcp_validation: onboarding.minimum_tcp_validation || {},
  } : {});
}

async function ensureWindowSession() {
  if (windowSessionId) {
    return;
  }
  const payload = await api("/local-api/window-session/open", {
    method: "POST",
    body: JSON.stringify({}),
  });
  windowSessionId = payload.session_id;
  renderWindowSessionStatus(payload);
  if (windowHeartbeatTimer) {
    window.clearInterval(windowHeartbeatTimer);
  }
  windowHeartbeatTimer = window.setInterval(async () => {
    if (!windowSessionId) {
      return;
    }
    try {
      const heartbeat = await api("/local-api/window-session/heartbeat", {
        method: "POST",
        body: JSON.stringify({}),
      });
      renderWindowSessionStatus(heartbeat);
    } catch (error) {
      console.warn("window session heartbeat failed", error);
    }
  }, 15000);
}

async function pollJob(jobId, outputId, feedbackId) {
  while (true) {
    const payload = await api(`/local-api/jobs/${jobId}`, { method: "GET" });
    writeOutput(outputId, payload);
    if (payload.status === "succeeded" || payload.status === "failed") {
      if (payload.status === "failed") {
        renderFeedback(feedbackId, { error: payload.error || { message: "Job failed" } });
      } else {
        clearFeedback(feedbackId);
      }
      return payload;
    }
    await new Promise((resolve) => window.setTimeout(resolve, 1200));
  }
}

async function refreshSnapshot() {
  const snapshot = await api("/local-api/onboarding/current", { method: "GET" });
  currentSnapshot = snapshot;
  renderSummary(snapshot);
  renderSectionOutputs(snapshot);
  const sessionId = snapshot?.onboarding_session?.session_id || null;
  if (sessionId) {
    setStoredOnboardingSessionId(sessionId);
  }
  const suggestedHost =
    snapshot?.onboarding_session?.effective_target_addr ||
    snapshot?.onboarding_session?.expected_wireguard_ip ||
    "";
  if (suggestedHost && !document.getElementById("tcp-host").value) {
    document.getElementById("tcp-host").value = suggestedHost;
  }
  return snapshot;
}

async function attachStoredSession() {
  const sessionId = getStoredOnboardingSessionId();
  if (!sessionId) {
    throw new Error("No saved onboarding session_id in browser storage.");
  }
  const payload = await api("/local-api/onboarding/attach", {
    method: "POST",
    body: JSON.stringify({ session_id: sessionId }),
  });
  clearFeedback("session-feedback");
  setStoredOnboardingSessionId(payload.session.session_id);
  renderDraftEditors(payload.phase1_drafts);
  writeOutput("session-output", payload);
  await refreshSnapshot();
  return payload;
}

async function submitProbe(path, editorId) {
  const payload = parseJsonEditor(editorId);
  const result = await api(path, {
    method: "POST",
    body: JSON.stringify(payload),
  });
  const sessionId = result?.session_id || result?.last_join_complete?.join_session_id || getStoredOnboardingSessionId();
  if (sessionId) {
    setStoredOnboardingSessionId(sessionId);
  }
  writeOutput("session-output", result);
  await refreshSnapshot();
  return result;
}

async function startJob(path, body, outputId, feedbackId) {
  const job = await api(path, {
    method: "POST",
    body: JSON.stringify(body || {}),
  });
  clearFeedback(feedbackId);
  const result = await pollJob(job.job_id, outputId, feedbackId);
  await refreshSnapshot();
  return result;
}

window.addEventListener("beforeunload", () => {
  if (!windowSessionId) {
    return;
  }
  fetch("/local-api/window-session/close", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "X-Window-Session-Id": windowSessionId,
    },
    body: JSON.stringify({}),
    keepalive: true,
  }).catch(() => {});
});

window.addEventListener("load", async () => {
  renderStoredSessionStatus(getStoredOnboardingSessionId());
  try {
    await ensureWindowSession();
    await refreshSnapshot();
  } catch (error) {
    handleError("session-output", "session-feedback", error);
  }
});

document.getElementById("login-form").addEventListener("submit", async (event) => {
  event.preventDefault();
  await ensureWindowSession();
  const form = new FormData(event.target);
  try {
    const result = await api("/local-api/auth/login", {
      method: "POST",
      body: JSON.stringify({
        email: form.get("email"),
        password: form.get("password"),
      }),
    });
    clearFeedback("session-feedback");
    writeOutput("session-output", result);
    if (getStoredOnboardingSessionId()) {
      await attachStoredSession();
    } else {
      await refreshSnapshot();
    }
  } catch (error) {
    handleError("session-output", "session-feedback", error);
  }
});

document.getElementById("register-form").addEventListener("submit", async (event) => {
  event.preventDefault();
  await ensureWindowSession();
  const form = new FormData(event.target);
  try {
    const result = await api("/local-api/auth/register", {
      method: "POST",
      body: JSON.stringify({
        email: form.get("email"),
        display_name: form.get("display_name"),
        password: form.get("password"),
      }),
    });
    clearFeedback("session-feedback");
    writeOutput("session-output", result);
    await refreshSnapshot();
  } catch (error) {
    handleError("session-output", "session-feedback", error);
  }
});

document.getElementById("session-form").addEventListener("submit", async (event) => {
  event.preventDefault();
  await ensureWindowSession();
  const form = new FormData(event.target);
  try {
    const result = await api("/local-api/onboarding/start", {
      method: "POST",
      body: JSON.stringify({
        requested_accelerator: form.get("requested_accelerator"),
        requested_compute_node_id: form.get("requested_compute_node_id") || null,
        requested_offer_tier: form.get("requested_offer_tier") || null,
        expected_wireguard_ip: form.get("expected_wireguard_ip") || null,
      }),
    });
    clearFeedback("session-feedback");
    setStoredOnboardingSessionId(result.session.session_id);
    renderDraftEditors(result.phase1_drafts);
    writeOutput("session-output", result);
    await refreshSnapshot();
  } catch (error) {
    handleError("session-output", "session-feedback", error);
  }
});

document.getElementById("attach-session").addEventListener("click", async () => {
  try {
    await ensureWindowSession();
    await attachStoredSession();
  } catch (error) {
    handleError("session-output", "session-feedback", error);
  }
});

document.getElementById("load-join-material").addEventListener("click", async () => {
  try {
    await ensureWindowSession();
    const result = await api("/local-api/onboarding/join-material", { method: "GET" });
    clearFeedback("session-feedback");
    writeOutput("join-material-output", result);
    await refreshSnapshot();
  } catch (error) {
    handleError("join-material-output", "session-feedback", error);
  }
});

document.getElementById("load-drafts").addEventListener("click", async () => {
  try {
    await ensureWindowSession();
    const drafts = await api("/local-api/onboarding/phase1-drafts", { method: "GET" });
    clearFeedback("session-feedback");
    renderDraftEditors(drafts);
    writeOutput("session-output", drafts);
  } catch (error) {
    handleError("session-output", "session-feedback", error);
  }
});

document.getElementById("close-session").addEventListener("click", async () => {
  try {
    await ensureWindowSession();
    const result = await api("/local-api/onboarding/close", {
      method: "POST",
      body: JSON.stringify({}),
    });
    clearFeedback("session-feedback");
    clearStoredOnboardingSessionId();
    writeOutput("session-output", result);
    await refreshSnapshot();
  } catch (error) {
    handleError("session-output", "session-feedback", error);
  }
});

document.getElementById("run-system-check").addEventListener("click", async () => {
  try {
    await ensureWindowSession();
    await startJob("/local-api/system/check", {}, "health-output", "system-feedback");
  } catch (error) {
    handleError("health-output", "system-feedback", error);
  }
});

document.getElementById("run-system-repair").addEventListener("click", async () => {
  try {
    await ensureWindowSession();
    await startJob("/local-api/system/repair", {}, "health-output", "system-feedback");
  } catch (error) {
    handleError("health-output", "system-feedback", error);
  }
});

document.getElementById("export-diagnostics").addEventListener("click", async () => {
  try {
    await ensureWindowSession();
    await startJob("/local-api/system/export-diagnostics", {}, "health-output", "system-feedback");
  } catch (error) {
    handleError("health-output", "system-feedback", error);
  }
});

document.getElementById("run-overlay-check").addEventListener("click", async () => {
  try {
    await ensureWindowSession();
    await startJob("/local-api/runtime/overlay-check", {}, "network-output", "network-feedback");
  } catch (error) {
    handleError("network-output", "network-feedback", error);
  }
});

document.getElementById("run-join-workflow").addEventListener("click", async () => {
  try {
    await ensureWindowSession();
    await startJob("/local-api/runtime/join-workflow", {}, "docker-output", "docker-feedback");
  } catch (error) {
    handleError("docker-output", "docker-feedback", error);
  }
});

document.getElementById("clear-join-state").addEventListener("click", async () => {
  try {
    await ensureWindowSession();
    await startJob("/local-api/runtime/clear-join-state", {}, "docker-output", "docker-feedback");
  } catch (error) {
    handleError("docker-output", "docker-feedback", error);
  }
});

document.getElementById("refresh-status").addEventListener("click", async () => {
  try {
    await ensureWindowSession();
    clearFeedback("docker-feedback");
    await refreshSnapshot();
  } catch (error) {
    handleError("docker-output", "docker-feedback", error);
  }
});

document.getElementById("tcp-validation-form").addEventListener("submit", async (event) => {
  event.preventDefault();
  await ensureWindowSession();
  const form = new FormData(event.target);
  try {
    const result = await api("/local-api/onboarding/tcp-validation", {
      method: "POST",
      body: JSON.stringify({
        host: form.get("host"),
        port: Number(form.get("port")),
        target_label: "manual_tcp_validation",
      }),
    });
    clearFeedback("network-feedback");
    writeOutput("network-output", result);
    await refreshSnapshot();
  } catch (error) {
    handleError("network-output", "network-feedback", error);
  }
});

document.getElementById("submit-host-probe").addEventListener("click", async () => {
  try {
    await ensureWindowSession();
    clearFeedback("session-feedback");
    await submitProbe("/local-api/onboarding/probes/linux-host", "host-probe-editor");
  } catch (error) {
    handleError("session-output", "session-feedback", error);
  }
});

document.getElementById("submit-substrate-probe").addEventListener("click", async () => {
  try {
    await ensureWindowSession();
    clearFeedback("session-feedback");
    await submitProbe("/local-api/onboarding/probes/linux-substrate", "substrate-probe-editor");
  } catch (error) {
    handleError("session-output", "session-feedback", error);
  }
});

document.getElementById("submit-runtime-probe").addEventListener("click", async () => {
  try {
    await ensureWindowSession();
    clearFeedback("session-feedback");
    await submitProbe("/local-api/onboarding/probes/container-runtime", "runtime-probe-editor");
  } catch (error) {
    handleError("session-output", "session-feedback", error);
  }
});

document.getElementById("submit-join-complete").addEventListener("click", async () => {
  try {
    await ensureWindowSession();
    clearFeedback("session-feedback");
    await submitProbe("/local-api/onboarding/join-complete", "join-complete-editor");
  } catch (error) {
    handleError("session-output", "session-feedback", error);
  }
});

document.getElementById("assistant-form").addEventListener("submit", async (event) => {
  event.preventDefault();
  await ensureWindowSession();
  const form = new FormData(event.target);
  try {
    const job = await api("/local-api/assistant/message", {
      method: "POST",
      body: JSON.stringify({ message: form.get("message") }),
    });
    clearFeedback("assistant-feedback");
    const result = await pollJob(job.job_id, "assistant-output", "assistant-feedback");
    if (result.result) {
      writeOutput("assistant-output", result.result);
    }
    await refreshSnapshot();
  } catch (error) {
    handleError("assistant-output", "assistant-feedback", error);
  }
});
