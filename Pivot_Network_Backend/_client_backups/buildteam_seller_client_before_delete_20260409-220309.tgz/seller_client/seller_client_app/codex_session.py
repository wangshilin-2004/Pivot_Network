from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Any

from seller_client_app.active_codex_session import (
    active_codex_session_pointer_path,
    clear_active_codex_session_pointer,
    write_active_codex_session_pointer,
)
from seller_client_app.config import Settings
from seller_client_app.state import SellerClientState, SessionRuntimePaths


class CodexSessionError(Exception):
    pass


def prepare_codex_session(
    *,
    settings: Settings,
    state: SellerClientState,
    session_id: str,
) -> SessionRuntimePaths:
    paths = state.session_paths(session_id)
    paths.codex_dotdir.mkdir(parents=True, exist_ok=True)
    paths.logs_dir.mkdir(parents=True, exist_ok=True)
    paths.workspace_dir.mkdir(parents=True, exist_ok=True)

    config_template = settings.codex_config_template_path
    auth_source = settings.codex_auth_source_path
    if not config_template.exists():
        raise CodexSessionError(f"Missing Codex config template: {config_template}")
    if not auth_source.exists():
        raise CodexSessionError(f"Missing Codex auth source: {auth_source}")

    (paths.codex_dotdir / "config.toml").write_text(config_template.read_text(encoding="utf-8"), encoding="utf-8")
    (paths.codex_dotdir / "auth.json").write_text(auth_source.read_text(encoding="utf-8"), encoding="utf-8")
    cap_sid_source = auth_source.parent / "cap_sid"
    if cap_sid_source.exists():
        (paths.codex_dotdir / "cap_sid").write_text(cap_sid_source.read_text(encoding="utf-8"), encoding="utf-8")

    session_file = state.write_session_runtime_file()
    if session_file is None:
        raise CodexSessionError("Onboarding session is not initialized.")
    write_active_codex_session_pointer(settings, paths)
    try:
        _register_mcp_server(settings, paths)
    except (OSError, subprocess.SubprocessError) as exc:
        raise CodexSessionError(f"failed to register MCP server: {exc}") from exc
    return paths


def run_codex_assistant(
    *,
    settings: Settings,
    state: SellerClientState,
    session_id: str,
    user_message: str,
) -> dict[str, Any]:
    session_payload = state.current_onboarding_session()
    if session_payload is None:
        raise CodexSessionError("Onboarding session is not initialized.")

    paths = prepare_codex_session(settings=settings, state=state, session_id=session_id)
    output_file = paths.logs_dir / "assistant-last-message.txt"
    prompt = _build_assistant_prompt(state.runtime_snapshot(), user_message)
    env = _codex_env(settings, paths)
    command = _codex_command(settings) + [
        "exec",
        "--skip-git-repo-check",
        "-s",
        settings.codex_exec_sandbox,
        "--cd",
        str(paths.workspace_dir),
        "--color",
        "never",
        "-o",
        str(output_file),
        prompt,
    ]
    process = subprocess.Popen(
        command,
        env=env,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        encoding="utf-8",
        errors="replace",
    )
    try:
        stdout, stderr = process.communicate(timeout=settings.codex_exec_timeout_seconds)
    except subprocess.TimeoutExpired as exc:
        process.kill()
        stdout, stderr = process.communicate()
        details = "\n".join(part.strip() for part in [stdout or "", stderr or ""] if part and part.strip()).strip()
        if details:
            if len(details) > 4000:
                details = details[:4000] + "\n...[truncated]"
            raise CodexSessionError(f"Codex assistant run timed out.\n{details}") from exc
        raise CodexSessionError("Codex assistant run timed out.") from exc
    stdout = stdout or ""
    stderr = stderr or ""

    if process.returncode != 0:
        raise CodexSessionError(stderr.strip() or stdout.strip() or "Codex assistant run failed.")
    mcp_failure = _detect_mcp_startup_failure(stdout=stdout, stderr=stderr)
    if mcp_failure is not None:
        raise CodexSessionError(mcp_failure)

    assistant_message = output_file.read_text(encoding="utf-8").strip() if output_file.exists() else ""
    result = {
        "assistant_mode": "codex_mcp_stdio_global",
        "assistant_message": assistant_message,
        "stdout": stdout.strip(),
        "stderr": stderr.strip(),
        "log_file": str(output_file),
        "session_root": str(paths.session_root),
        "mcp_transport": "stdio",
        "mcp_server_name": _mcp_server_name(settings, session_id),
        "mcp_server_command": str(_stdio_mcp_script_path(settings)),
        "active_session_pointer": str(active_codex_session_pointer_path(settings)),
    }
    state.record_assistant_run(result)
    return result


def cleanup_codex_session(
    *,
    settings: Settings,
    state: SellerClientState,
    session_id: str,
) -> None:
    clear_active_codex_session_pointer(settings, session_id=session_id)
    state.cleanup_session(session_id)


def _register_mcp_server(settings: Settings, paths: SessionRuntimePaths) -> None:
    del paths
    _attach_stdio_mcp_to_global_config(settings)


def _mcp_server_name(settings: Settings, session_id: str) -> str:
    del session_id
    return settings.codex_mcp_server_name_prefix


def _codex_env(settings: Settings, paths: SessionRuntimePaths) -> dict[str, str]:
    env = os.environ.copy()
    env["SELLER_CLIENT_SESSION_FILE"] = str(paths.session_file)
    env["SELLER_CLIENT_ACTIVE_SESSION_POINTER"] = str(active_codex_session_pointer_path(settings))
    env["PYTHONPATH"] = str(Path(__file__).resolve().parent.parent)
    return env


def _attach_stdio_mcp_to_global_config(settings: Settings) -> None:
    config_path = _global_codex_config_path()
    config_path.parent.mkdir(parents=True, exist_ok=True)
    existing = config_path.read_text(encoding="utf-8") if config_path.exists() else ""
    updated = _upsert_mcp_block(existing, _mcp_server_name(settings, ""), _desired_stdio_mcp_block(settings))
    if updated != existing:
        config_path.write_text(updated, encoding="utf-8")


def _desired_stdio_mcp_block(settings: Settings) -> str:
    python_exe = _normalized_path(shutil.which("python") or sys.executable)
    script_path = _normalized_path(str(_stdio_mcp_script_path(settings)))
    cwd_path = _normalized_path(str(settings.project_root))
    return (
        f"\n[mcp_servers.{_mcp_server_name(settings, '')}]\n"
        f"command = {json.dumps(python_exe, ensure_ascii=False)}\n"
        f"args = [{json.dumps(script_path, ensure_ascii=False)}]\n"
        f"cwd = {json.dumps(cwd_path, ensure_ascii=False)}\n"
    )


def _upsert_mcp_block(config_text: str, server_name: str, block: str) -> str:
    pattern = re.compile(rf"(?ms)^\[mcp_servers\.{re.escape(server_name)}\]\n.*?(?=^\[|\Z)")
    stripped = config_text.rstrip()
    if pattern.search(stripped):
        updated = pattern.sub(block.strip() + "\n\n", stripped, count=1)
        return updated.rstrip() + "\n"
    if not stripped:
        return block.lstrip()
    return stripped + block + "\n"


def _normalized_path(value: str) -> str:
    return value.replace("\\", "/")


def _stdio_mcp_script_path(settings: Settings) -> Path:
    return settings.project_root / "scripts" / "run-seller-fastmcp.py"


def _remove_stale_global_mcp_server(settings: Settings, server_name: str, *, env: dict[str, str]) -> None:
    details = _mcp_get_output(settings, server_name, env=env)
    if not details:
        return
    session_file = _extract_session_file_path(details)
    if session_file is None or session_file.exists():
        return
    subprocess.run(
        _codex_command(settings) + ["mcp", "remove", server_name],
        env=env,
        check=False,
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
        timeout=15,
    )
    _remove_mcp_sections_from_global_config(server_name)


def _mcp_get_output(settings: Settings, server_name: str, *, env: dict[str, str]) -> str:
    completed = subprocess.run(
        _codex_command(settings) + ["mcp", "get", server_name],
        env=env,
        check=False,
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
        timeout=15,
    )
    if completed.returncode != 0:
        return ""
    return f"{completed.stdout or ''}\n{completed.stderr or ''}".strip()


def _extract_session_file_path(details: str) -> Path | None:
    marker = "--session-file "
    if marker not in details:
        return None
    tail = details.split(marker, 1)[1].strip()
    line = tail.splitlines()[0].strip()
    if not line:
        return None
    return Path(line)


def _remove_mcp_sections_from_global_config(server_name: str) -> None:
    config_path = _global_codex_config_path()
    if not config_path.exists():
        return
    text = config_path.read_text(encoding="utf-8")
    target_sections = {
        f"mcp_servers.{server_name}",
        f"mcp_servers.{server_name}.env",
    }
    lines = text.splitlines()
    output: list[str] = []
    skip = False
    for line in lines:
        stripped = line.strip()
        if stripped.startswith("[") and stripped.endswith("]"):
            section_name = stripped[1:-1]
            skip = section_name in target_sections
            if skip:
                continue
        if skip:
            continue
        output.append(line)
    updated = "\n".join(output).rstrip() + "\n"
    if updated != text:
        config_path.write_text(updated, encoding="utf-8")


def _prune_prefixed_mcp_sections_from_global_config(prefix: str, *, keep_name: str) -> None:
    config_path = _global_codex_config_path()
    if not config_path.exists():
        return
    text = config_path.read_text(encoding="utf-8")
    lines = text.splitlines()
    output: list[str] = []
    skip = False

    for line in lines:
        stripped = line.strip()
        if stripped.startswith("[") and stripped.endswith("]"):
            section_name = stripped[1:-1]
            parts = section_name.split(".")
            skip = False
            if len(parts) >= 2 and parts[0] == "mcp_servers":
                server_name = parts[1]
                if server_name.startswith(f"{prefix}-") and server_name != keep_name:
                    skip = True
            if skip:
                continue
        if skip:
            continue
        output.append(line)

    updated = "\n".join(output).rstrip() + "\n"
    if updated != text:
        config_path.write_text(updated, encoding="utf-8")


def _global_codex_config_path() -> Path:
    return Path.home() / ".codex" / "config.toml"


def _codex_command(settings: Settings) -> list[str]:
    candidate = shutil.which(settings.codex_command)
    if candidate is None:
        raise CodexSessionError(f"Unable to locate Codex CLI command: {settings.codex_command}")
    return [candidate]


def _build_assistant_prompt(snapshot: dict[str, Any], user_message: str) -> str:
    return (
        "You are the seller onboarding assistant for Pivot Network.\n"
        "Use only the configured MCP tools for this session.\n"
        "Do not assume shell access and do not ask the user to edit files manually.\n"
        "Work from the existing backend onboarding contract, the generated phase-1 drafts, and the local environment health tools.\n"
        "Prefer the controlled workflow tools for environment checks, overlay checks, join workflow, and diagnostics export.\n"
        "When the user asks for onboarding state, health checks, overlay checks, join workflow, refresh, or TCP validation, you must call the relevant MCP tools before replying.\n"
        "Do not reply with a generic capabilities summary when tool calls are applicable.\n"
        "When the user asks to clear, reset, clean up, or retry seller join state from scratch, call clear_join_state before retrying the join flow.\n"
        "For stable join execution, prefer this order unless the user explicitly narrows it: refresh_onboarding_session, read_join_material, run_guided_join_assessment.\n"
        "For seller join or verification requests, call run_guided_join_assessment first unless the user explicitly asks for a narrower tool.\n"
        "Your join-effect answer must explicitly cover: local environment health, join material, local join result, manager raw truth, backend authoritative target, and minimum TCP validation.\n"
        "Treat local join state, manager raw truth, backend authoritative target, and TCP validation as separate layers.\n"
        "If a required runtime fact is missing, state the exact missing field instead of guessing.\n"
        "Current local state:\n"
        f"{json.dumps(snapshot, ensure_ascii=False, indent=2)}\n\n"
        "User request:\n"
        f"{user_message}\n"
    )


def _detect_mcp_startup_failure(*, stdout: str, stderr: str) -> str | None:
    combined = "\n".join(part for part in [stderr.strip(), stdout.strip()] if part).strip()
    lowered = combined.lower()
    markers = (
        "mcp startup: failed",
        "failed to start: mcp startup failed",
        "handshaking with mcp server failed",
    )
    if not any(marker in lowered for marker in markers):
        return None

    lines = [line.strip() for line in combined.splitlines() if line.strip()]
    relevant = [line for line in lines if "mcp" in line.lower() or "rmcp" in line.lower()]
    excerpt = "\n".join(relevant[:12]).strip()
    if excerpt:
        return f"Codex MCP startup failed.\n{excerpt}"
    return "Codex MCP startup failed."
