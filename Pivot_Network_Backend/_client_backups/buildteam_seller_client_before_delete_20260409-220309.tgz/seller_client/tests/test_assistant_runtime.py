from __future__ import annotations

import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from seller_client_app.assistant_runtime import classify_assistant_intent, execute_assistant_request
from seller_client_app.codex_session import CodexSessionError
from seller_client_app.config import Settings
from seller_client_app.state import SellerClientState


def sample_session_payload() -> dict[str, object]:
    return {
        "session_id": "join-session-0001",
        "seller_user_id": "seller-user-0001",
        "status": "issued",
        "requested_offer_tier": "medium",
        "requested_accelerator": "gpu",
        "requested_compute_node_id": "compute-seller-1",
        "swarm_join_material": {
            "manager_addr": "81.70.52.75",
            "manager_port": 2377,
            "swarm_join_command": "docker swarm join --token join-token-1 81.70.52.75:2377",
            "recommended_compute_node_id": "compute-seller-1",
            "registry_host": "registry.example.com",
            "registry_port": 5000,
            "recommended_labels": {
                "platform.role": "compute",
                "platform.compute_node_id": "compute-seller-1",
                "platform.seller_user_id": "seller-user-0001",
            },
        },
        "required_labels": {
            "platform.role": "compute",
            "platform.compute_node_id": "compute-seller-1",
            "platform.seller_user_id": "seller-user-0001",
        },
        "expected_wireguard_ip": "10.66.66.10",
        "probe_summary": None,
        "container_runtime_probe": None,
        "last_join_complete": None,
        "manager_acceptance": {
            "status": "pending",
            "expected_wireguard_ip": "10.66.66.10",
            "observed_manager_node_addr": None,
            "matched": None,
            "detail": "not_checked",
        },
        "effective_target_addr": None,
        "effective_target_source": None,
        "truth_authority": "raw_manager",
        "minimum_tcp_validation": None,
    }


class AssistantRuntimeTests(unittest.TestCase):
    def test_classify_assistant_intent_detects_operational_join_prompt(self) -> None:
        intent = classify_assistant_intent("先检查环境，再执行 join workflow，最后刷新状态")
        self.assertTrue(intent.use_local_workflow)
        self.assertFalse(intent.prefers_codex)
        self.assertTrue(intent.wants_environment_check)
        self.assertTrue(intent.wants_overlay_check)
        self.assertTrue(intent.wants_join_workflow)
        self.assertTrue(intent.wants_refresh)

    def test_execute_assistant_request_runs_local_join_workflow_for_operational_prompt(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir_path = Path(tmpdir)
            settings = Settings(windows_workspace_root=str(tmpdir_path / "workspace"))
            state = SellerClientState(settings)
            state.set_auth(
                "token-1",
                {"id": "user-1", "email": "seller@example.com"},
                "2026-04-07T23:00:00Z",
            )
            state.set_onboarding(sample_session_payload())

            refreshed_session = sample_session_payload()
            refreshed_session["status"] = "verify_failed"
            refreshed_session["manager_acceptance"] = {
                "status": "verify_failed",
                "expected_wireguard_ip": "10.66.66.10",
                "observed_manager_node_addr": "202.113.184.2",
                "matched": False,
                "detail": "manager raw truth does not match expected wireguard ip",
            }
            refreshed_session["effective_target_addr"] = "10.66.66.10"
            refreshed_session["effective_target_source"] = "backend_correction"
            refreshed_session["truth_authority"] = "backend_correction"
            refreshed_session["minimum_tcp_validation"] = {
                "target_addr": "10.66.66.10",
                "target_port": 8080,
                "reachable": False,
            }

            health_payload = {
                "report_path": str(tmpdir_path / "workspace" / "health" / "latest-health-report.json"),
                "summary": {"status": "needs_attention", "warnings": ["wsl", "wireguard"]},
                "docker": {"local_node_state": "active", "node_addr": "10.66.66.10"},
            }
            overlay_payload = {"ok": True, "payload": {"windows_overlay": {"manager_routes": ["10.66.66.1 dev wg-seller"]}}}
            workflow_payload = {
                "ok": True,
                "payload": {
                    "join_result": {
                        "after_state": '{"LocalNodeState":"active","NodeAddr":"10.66.66.10"}',
                    }
                },
            }

            with (
                patch("seller_client_app.assistant_runtime.collect_environment_health", return_value=health_payload),
                patch("seller_client_app.assistant_runtime.run_overlay_runtime_check", return_value=overlay_payload),
                patch("seller_client_app.assistant_runtime.run_standard_join_workflow", return_value=workflow_payload),
                patch("seller_client_app.assistant_runtime.BackendClient.get_onboarding_session", return_value=refreshed_session),
            ):
                result = execute_assistant_request(
                    settings=settings,
                    state=state,
                    session_id="join-session-0001",
                    user_message="先读取环境健康和 onboarding 状态，再执行标准 join workflow，最后说 raw manager / authoritative target / tcp validation 的当前结果。",
                )

            self.assertEqual(result["assistant_mode"], "local_controlled_workflow")
            self.assertEqual(
                [item["action"] for item in result["actions_run"]],
                ["environment_check", "overlay_check", "join_workflow", "minimum_tcp_validation"],
            )
            self.assertIn("manager raw truth", result["assistant_message"])
            self.assertEqual(state.current_onboarding_session()["status"], "verify_failed")
            self.assertEqual(state.current_last_runtime_workflow()["kind"], "standard_join_workflow")
            self.assertEqual(state.current_local_health_snapshot()["summary"]["status"], "needs_attention")

    def test_execute_assistant_request_uses_codex_for_non_operational_prompt(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            settings = Settings(windows_workspace_root=str(Path(tmpdir) / "workspace"))
            state = SellerClientState(settings)
            state.set_onboarding(sample_session_payload())

            with patch(
                "seller_client_app.assistant_runtime.run_codex_assistant",
                return_value={"assistant_message": "assistant ok", "assistant_mode": "codex_mcp"},
            ) as run_codex:
                result = execute_assistant_request(
                    settings=settings,
                    state=state,
                    session_id="join-session-0001",
                    user_message="帮我写一段卖家欢迎文案",
                )

            run_codex.assert_called_once()
            self.assertEqual(result["assistant_message"], "assistant ok")

    def test_execute_assistant_request_prefers_codex_when_prompt_explicitly_mentions_mcp(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            settings = Settings(windows_workspace_root=str(Path(tmpdir) / "workspace"))
            state = SellerClientState(settings)
            state.set_onboarding(sample_session_payload())

            with patch(
                "seller_client_app.assistant_runtime.run_codex_assistant",
                return_value={"assistant_message": "mcp ok", "assistant_mode": "codex_mcp"},
            ) as run_codex:
                result = execute_assistant_request(
                    settings=settings,
                    state=state,
                    session_id="join-session-0001",
                    user_message="请通过 Codex MCP 读取 onboarding state",
                )

            run_codex.assert_called_once()
            self.assertEqual(result["assistant_message"], "mcp ok")

    def test_execute_assistant_request_falls_back_to_local_summary_when_codex_fails(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            settings = Settings(windows_workspace_root=str(Path(tmpdir) / "workspace"))
            state = SellerClientState(settings)
            state.set_onboarding(sample_session_payload())

            with patch(
                "seller_client_app.assistant_runtime.run_codex_assistant",
                side_effect=CodexSessionError("mcp timeout"),
            ):
                result = execute_assistant_request(
                    settings=settings,
                    state=state,
                    session_id="join-session-0001",
                    user_message="帮我写一段卖家欢迎文案",
                )

            self.assertEqual(result["assistant_mode"], "local_state_fallback")
            self.assertEqual(result["actions_run"][0]["action"], "read_state")

    def test_execute_assistant_request_falls_back_to_local_workflow_when_codex_fails_for_explicit_mcp_prompt(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir_path = Path(tmpdir)
            settings = Settings(windows_workspace_root=str(tmpdir_path / "workspace"))
            state = SellerClientState(settings)
            state.set_auth(
                "token-1",
                {"id": "user-1", "email": "seller@example.com"},
                "2026-04-07T23:00:00Z",
            )
            state.set_onboarding(sample_session_payload())

            refreshed_session = sample_session_payload()
            refreshed_session["status"] = "verify_failed"
            refreshed_session["effective_target_addr"] = "10.66.66.10"
            refreshed_session["effective_target_source"] = "backend_correction"
            refreshed_session["truth_authority"] = "backend_correction"
            refreshed_session["minimum_tcp_validation"] = {
                "target_addr": "10.66.66.10",
                "target_port": 8080,
                "reachable": False,
            }
            health_payload = {
                "report_path": str(tmpdir_path / "workspace" / "health" / "latest-health-report.json"),
                "summary": {"status": "needs_attention", "warnings": ["wireguard"]},
                "docker": {"local_node_state": "active", "node_addr": "10.66.66.10"},
            }
            overlay_payload = {"ok": True, "payload": {"windows_overlay": {"manager_routes": ["10.66.66.1 dev wg-seller"]}}}
            workflow_payload = {
                "ok": True,
                "payload": {"join_result": {"after_state": '{"LocalNodeState":"active","NodeAddr":"10.66.66.10"}'}},
            }

            with (
                patch(
                    "seller_client_app.assistant_runtime.run_codex_assistant",
                    side_effect=CodexSessionError("mcp timeout"),
                ),
                patch("seller_client_app.assistant_runtime.collect_environment_health", return_value=health_payload),
                patch("seller_client_app.assistant_runtime.run_overlay_runtime_check", return_value=overlay_payload),
                patch("seller_client_app.assistant_runtime.run_standard_join_workflow", return_value=workflow_payload),
                patch("seller_client_app.assistant_runtime.BackendClient.get_onboarding_session", return_value=refreshed_session),
            ):
                result = execute_assistant_request(
                    settings=settings,
                    state=state,
                    session_id="join-session-0001",
                    user_message="请通过 Codex MCP 执行 join workflow，然后总结状态",
                )

            self.assertEqual(result["assistant_mode"], "local_controlled_workflow_with_codex_fallback")
            self.assertEqual(result["codex_error"], "mcp timeout")
            self.assertEqual(result["actions_run"][0]["action"], "environment_check")


if __name__ == "__main__":
    unittest.main()
