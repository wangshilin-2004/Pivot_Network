from __future__ import annotations

import sys
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from seller_client_app.codex_session import CodexSessionError, prepare_codex_session, run_codex_assistant
from seller_client_app.config import Settings
from seller_client_app.state import SellerClientState


def sample_session_payload() -> dict[str, object]:
    return {
        "session_id": "join-session-0001",
        "seller_user_id": "seller-user-0001",
        "status": "issued",
        "requested_offer_tier": "medium",
        "requested_accelerator": "gpu",
        "requested_compute_node_id": "compute-seller-1",
        "swarm_join_material": {
            "manager_addr": "81.70.52.75",
            "manager_port": 2377,
            "swarm_join_command": "docker swarm join --token join-token-1 81.70.52.75:2377",
            "recommended_compute_node_id": "compute-seller-1",
            "registry_host": "registry.example.com",
            "registry_port": 5000,
            "recommended_labels": {
                "platform.role": "compute",
                "platform.compute_node_id": "compute-seller-1",
                "platform.seller_user_id": "seller-user-0001",
            },
        },
        "required_labels": {
            "platform.role": "compute",
            "platform.compute_node_id": "compute-seller-1",
            "platform.seller_user_id": "seller-user-0001",
        },
        "expected_wireguard_ip": "10.0.8.12",
        "probe_summary": None,
        "container_runtime_probe": None,
        "last_join_complete": None,
        "manager_acceptance": {"status": "pending"},
    }


class FakeProcess:
    def __init__(self, command: list[str]) -> None:
        self.command = command
        self.returncode = 0
        output_path = Path(command[command.index("-o") + 1])
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_text("assistant ok", encoding="utf-8")

    def communicate(self, timeout: int) -> tuple[str, str]:
        del timeout
        return ("stdout ok", "")


class FakeMcpFailureProcess(FakeProcess):
    def communicate(self, timeout: int) -> tuple[str, str]:
        del timeout
        return (
            "stdout ok",
            "mcp: seller-client-tools-session_x starting\nmcp startup: failed: seller-client-tools-session_x\n"
            "handshaking with MCP server failed\n",
        )


class CodexSessionTests(unittest.TestCase):
    def test_prepare_and_run_assistant_use_session_scoped_codex_home(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir_path = Path(tmpdir)
            config_template = tmpdir_path / "codex.config.toml"
            auth_file = tmpdir_path / "auth.json"
            config_template.write_text("model = 'gpt-5.4'\n", encoding="utf-8")
            auth_file.write_text('{"token":"secret"}\n', encoding="utf-8")

            settings = Settings(
                windows_workspace_root=str(tmpdir_path / "workspace"),
                non_windows_workspace_root=str(tmpdir_path / "workspace"),
                codex_config_template_path=config_template,
                codex_auth_source_path=auth_file,
            )
            runtime_state = SellerClientState(settings)
            runtime_state.set_auth(
                "token-1",
                {"id": "user-1", "email": "seller@example.com"},
                "2026-04-07T23:00:00Z",
            )
            runtime_state.set_onboarding(sample_session_payload())

            def fake_run(*args, **kwargs):
                del args, kwargs
                return SimpleNamespace(returncode=0, stdout="", stderr="")

            with (
                patch("seller_client_app.codex_session.shutil.which", return_value="/usr/bin/codex"),
                patch("seller_client_app.codex_session._global_codex_config_path", return_value=tmpdir_path / "global-codex-config.toml"),
                patch("seller_client_app.codex_session.subprocess.run", side_effect=fake_run),
                patch(
                    "seller_client_app.codex_session.subprocess.Popen",
                    side_effect=lambda command, **kwargs: FakeProcess(command),
                ),
            ):
                paths = prepare_codex_session(settings=settings, state=runtime_state, session_id="join-session-0001")
                self.assertTrue((paths.codex_dotdir / "config.toml").exists())
                self.assertTrue((paths.codex_dotdir / "auth.json").exists())
                global_config = (tmpdir_path / "global-codex-config.toml").read_text(encoding="utf-8")
                self.assertIn("[mcp_servers.seller-client-tools]", global_config)
                self.assertIn("run-seller-fastmcp.py", global_config)

                result = run_codex_assistant(
                    settings=settings,
                    state=runtime_state,
                    session_id="join-session-0001",
                    user_message="read state",
                )
                self.assertEqual(result["assistant_message"], "assistant ok")
                self.assertEqual(result["assistant_mode"], "codex_mcp_stdio_global")
                self.assertIn("session_root", result)

    def test_run_codex_assistant_raises_when_mcp_startup_failed_even_if_exit_code_is_zero(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir_path = Path(tmpdir)
            config_template = tmpdir_path / "codex.config.toml"
            auth_file = tmpdir_path / "auth.json"
            config_template.write_text("model = 'gpt-5.4'\n", encoding="utf-8")
            auth_file.write_text('{"token":"secret"}\n', encoding="utf-8")

            settings = Settings(
                windows_workspace_root=str(tmpdir_path / "workspace"),
                non_windows_workspace_root=str(tmpdir_path / "workspace"),
                codex_config_template_path=config_template,
                codex_auth_source_path=auth_file,
            )
            runtime_state = SellerClientState(settings)
            runtime_state.set_auth(
                "token-1",
                {"id": "user-1", "email": "seller@example.com"},
                "2026-04-07T23:00:00Z",
            )
            runtime_state.set_onboarding(sample_session_payload())

            def fake_run(*args, **kwargs):
                del args, kwargs
                return SimpleNamespace(returncode=0, stdout="", stderr="")

            with (
                patch("seller_client_app.codex_session.shutil.which", return_value="/usr/bin/codex"),
                patch("seller_client_app.codex_session._global_codex_config_path", return_value=tmpdir_path / "global-codex-config.toml"),
                patch("seller_client_app.codex_session.subprocess.run", side_effect=fake_run),
                patch(
                    "seller_client_app.codex_session.subprocess.Popen",
                    side_effect=lambda command, **kwargs: FakeMcpFailureProcess(command),
                ),
            ):
                prepare_codex_session(settings=settings, state=runtime_state, session_id="join-session-0001")
                with self.assertRaises(CodexSessionError):
                    run_codex_assistant(
                        settings=settings,
                        state=runtime_state,
                        session_id="join-session-0001",
                        user_message="read state",
                    )
